// Driver Exam Prep – App Context (React Native)
// Manages global state: exams, attempts, language
// Persists via AsyncStorage

import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Exam, ExamAttempt, ExamData, LangCode } from '../types';

interface AppContextValue {
  exams: Exam[];
  loading: boolean;
  attempts: ExamAttempt[];
  disclaimerAcknowledged: boolean;
  acknowledgeDisclaimer: () => Promise<void>;
  saveAttempt: (attempt: ExamAttempt) => Promise<void>;
  getBestAttempt: (examId: number) => ExamAttempt | null;
  getAttemptsForExam: (examId: number) => ExamAttempt[];
  clearAllProgress: () => Promise<void>;
  examsAttemptedCount: number;
  examsPassedCount: number;
  lang: LangCode;
  setLang: (lang: LangCode) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_ATTEMPTS = '@driverExam:attempts';
const STORAGE_DISCLAIMER = '@driverExam:disclaimer';
const STORAGE_LANG = '@driverExam:lang';

const QUESTIONS_FILES: Record<LangCode, any> = {
  en: require('../../assets/data/questions_en.json'),
  es: require('../../assets/data/questions_es.json'),
  'pt-BR': require('../../assets/data/questions_pt-BR.json'),
};

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<LangCode>('en');
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [disclaimerAcknowledged, setDisclaimerAcknowledged] = useState(false);
  const initialized = useRef(false);

  // Load persisted state on mount
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    async function init() {
      try {
        const [savedLang, savedAttempts, savedDisclaimer] = await Promise.all([
          AsyncStorage.getItem(STORAGE_LANG),
          AsyncStorage.getItem(STORAGE_ATTEMPTS),
          AsyncStorage.getItem(STORAGE_DISCLAIMER),
        ]);

        const activeLang: LangCode =
          savedLang === 'en' || savedLang === 'es' || savedLang === 'pt-BR'
            ? savedLang
            : 'en';
        setLangState(activeLang);

        if (savedAttempts) {
          setAttempts(JSON.parse(savedAttempts));
        }
        if (savedDisclaimer === 'true') {
          setDisclaimerAcknowledged(true);
        }

        loadExamsForLang(activeLang);
      } catch {
        loadExamsForLang('en');
      }
    }

    init();
  }, []);

  function loadExamsForLang(language: LangCode) {
    setLoading(true);
    try {
      const data: ExamData = QUESTIONS_FILES[language];
      const sorted = [...data.exams].sort((a, b) => a.id - b.id);
      setExams(sorted);
    } catch {
      // Fallback to English
      const data: ExamData = QUESTIONS_FILES['en'];
      const sorted = [...data.exams].sort((a, b) => a.id - b.id);
      setExams(sorted);
    }
    setLoading(false);
  }

  const setLang = useCallback(async (newLang: LangCode) => {
    await AsyncStorage.setItem(STORAGE_LANG, newLang);
    setLangState(newLang);
    loadExamsForLang(newLang);
  }, []);

  const acknowledgeDisclaimer = useCallback(async () => {
    await AsyncStorage.setItem(STORAGE_DISCLAIMER, 'true');
    setDisclaimerAcknowledged(true);
  }, []);

  const saveAttempt = useCallback(async (attempt: ExamAttempt) => {
    setAttempts((prev) => {
      const next = [attempt, ...prev];
      AsyncStorage.setItem(STORAGE_ATTEMPTS, JSON.stringify(next));
      return next;
    });
  }, []);

  const getBestAttempt = useCallback(
    (examId: number): ExamAttempt | null => {
      const forExam = attempts.filter((a) => a.examId === examId);
      if (forExam.length === 0) return null;
      return forExam.reduce((best, a) => (a.score > best.score ? a : best));
    },
    [attempts]
  );

  const getAttemptsForExam = useCallback(
    (examId: number): ExamAttempt[] => {
      return attempts.filter((a) => a.examId === examId);
    },
    [attempts]
  );

  const clearAllProgress = useCallback(async () => {
    await AsyncStorage.removeItem(STORAGE_ATTEMPTS);
    setAttempts([]);
  }, []);

  const examsAttemptedCount = new Set(attempts.map((a) => a.examId)).size;
  const examsPassedCount = exams.filter((e) => {
    const best = getBestAttempt(e.id);
    return best !== null && best.passed;
  }).length;

  return (
    <AppContext.Provider
      value={{
        exams,
        loading,
        attempts,
        disclaimerAcknowledged,
        acknowledgeDisclaimer,
        saveAttempt,
        getBestAttempt,
        getAttemptsForExam,
        clearAllProgress,
        examsAttemptedCount,
        examsPassedCount,
        lang,
        setLang,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
