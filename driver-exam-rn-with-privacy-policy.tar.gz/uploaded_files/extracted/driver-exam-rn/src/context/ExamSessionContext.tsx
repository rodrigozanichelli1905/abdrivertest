// Driver Exam Prep – Exam Session Context (React Native)
// Manages a single in-progress exam attempt

import React, { createContext, useContext, useState, useCallback } from 'react';
import type { Exam, ExamAttempt, Question } from '../types';

const PASS_THRESHOLD = 25;

interface ExamSessionContextValue {
  exam: Exam | null;
  currentIndex: number;
  answers: Record<string, number>;
  startExam: (exam: Exam) => void;
  selectAnswer: (optionIndex: number) => void;
  nextQuestion: () => void;
  previousQuestion: () => void;
  goToQuestion: (index: number) => void;
  resetSession: () => void;
  currentQuestion: Question | null;
  hasNext: boolean;
  hasPrevious: boolean;
  allAnswered: boolean;
  answeredCount: number;
  totalQuestions: number;
  computeScore: () => number;
  buildAttempt: () => ExamAttempt;
  selectedAnswerFor: (questionId: string) => number | undefined;
}

const ExamSessionContext = createContext<ExamSessionContextValue | null>(null);

export function ExamSessionProvider({ children }: { children: React.ReactNode }) {
  const [exam, setExam] = useState<Exam | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});

  const startExam = useCallback((newExam: Exam) => {
    setExam(newExam);
    setCurrentIndex(0);
    setAnswers({});
  }, []);

  const selectAnswer = useCallback(
    (optionIndex: number) => {
      if (!exam) return;
      const q = exam.questions[currentIndex];
      if (!q) return;
      setAnswers((prev) => ({ ...prev, [q.id]: optionIndex }));
    },
    [exam, currentIndex]
  );

  const nextQuestion = useCallback(() => {
    if (!exam) return;
    setCurrentIndex((i) => Math.min(i + 1, exam.questions.length - 1));
  }, [exam]);

  const previousQuestion = useCallback(() => {
    setCurrentIndex((i) => Math.max(i - 1, 0));
  }, []);

  const goToQuestion = useCallback(
    (index: number) => {
      if (!exam) return;
      if (index >= 0 && index < exam.questions.length) {
        setCurrentIndex(index);
      }
    },
    [exam]
  );

  const resetSession = useCallback(() => {
    setExam(null);
    setCurrentIndex(0);
    setAnswers({});
  }, []);

  const currentQuestion = exam ? (exam.questions[currentIndex] ?? null) : null;
  const hasNext = exam ? currentIndex < exam.questions.length - 1 : false;
  const hasPrevious = currentIndex > 0;
  const totalQuestions = exam?.questions.length ?? 0;
  const allAnswered = exam ? Object.keys(answers).length === totalQuestions : false;
  const answeredCount = Object.keys(answers).length;

  const selectedAnswerFor = useCallback(
    (questionId: string) => answers[questionId],
    [answers]
  );

  const computeScore = useCallback(() => {
    if (!exam) return 0;
    let score = 0;
    for (const q of exam.questions) {
      const selected = answers[q.id];
      if (selected !== undefined && selected === q.correct) score++;
    }
    return score;
  }, [exam, answers]);

  const buildAttempt = useCallback((): ExamAttempt => {
    if (!exam) throw new Error('No exam in progress');
    const score = computeScore();
    return {
      examId: exam.id,
      score,
      totalQuestions: exam.questions.length,
      completedAt: new Date().toISOString(),
      answers: { ...answers },
      passed: score >= PASS_THRESHOLD,
    };
  }, [exam, answers, computeScore]);

  return (
    <ExamSessionContext.Provider
      value={{
        exam,
        currentIndex,
        answers,
        startExam,
        selectAnswer,
        nextQuestion,
        previousQuestion,
        goToQuestion,
        resetSession,
        currentQuestion,
        hasNext,
        hasPrevious,
        allAnswered,
        answeredCount,
        totalQuestions,
        computeScore,
        buildAttempt,
        selectedAnswerFor,
      }}
    >
      {children}
    </ExamSessionContext.Provider>
  );
}

export function useExamSession() {
  const ctx = useContext(ExamSessionContext);
  if (!ctx) throw new Error('useExamSession must be used within ExamSessionProvider');
  return ctx;
}
