// Driver Exam Prep – Profile Screen (React Native)

import React, { useMemo, useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert,
} from 'react-native';
import { useApp } from '../context/AppContext';
import { t, LANG_OPTIONS } from '../i18n';
import { Colors, Radius, Shadow } from '../components/theme';
import type { LangCode } from '../types';

function CategoryStats() {
  const { exams, attempts, lang } = useApp();

  const stats = useMemo(() => {
    if (exams.length === 0 || attempts.length === 0) return [];
    const bestMap = new Map<number, typeof attempts[0]>();
    for (const a of attempts) {
      const ex = bestMap.get(a.examId);
      if (!ex || a.score > ex.score) bestMap.set(a.examId, a);
    }
    const catExams = new Map<string, typeof exams>();
    for (const e of exams) {
      const list = catExams.get(e.category) ?? [];
      list.push(e);
      catExams.set(e.category, list);
    }
    const result: { category: string; accuracy: number; correct: number; total: number; tried: number; examCount: number }[] = [];
    for (const [cat, ces] of Array.from(catExams.entries())) {
      let correct = 0, total = 0, tried = 0;
      for (const e of ces) {
        const best = bestMap.get(e.id);
        if (!best) continue;
        tried++;
        for (const q of e.questions) {
          const sel = best.answers[q.id];
          if (sel !== undefined) {
            total++;
            if (sel === q.correct) correct++;
          }
        }
      }
      if (tried === 0) continue;
      result.push({ category: cat, accuracy: total > 0 ? Math.round((correct / total) * 100) : 0, correct, total, tried, examCount: ces.length });
    }
    return result.sort((a, b) => a.accuracy - b.accuracy);
  }, [exams, attempts]);

  if (stats.length === 0) {
    return (
      <View style={styles.emptyStats}>
        <Text style={styles.emptyStatsText}>{t(lang, 'noCategoryStats')}</Text>
      </View>
    );
  }

  const worst = stats[0];
  const best = stats[stats.length - 1];

  return (
    <View>
      {stats.length >= 2 && (
        <View style={styles.summaryRow}>
          <View style={[styles.summaryPill, { backgroundColor: '#E0483E10', borderColor: '#E0483E33' }]}>
            <Text style={[styles.summaryLabel, { color: Colors.danger }]}>{t(lang, 'weakest')}</Text>
            <Text style={styles.summaryCategory} numberOfLines={1}>{worst.category}</Text>
            <Text style={[styles.summaryPct, { color: Colors.danger }]}>{worst.accuracy}%</Text>
          </View>
          <View style={[styles.summaryPill, { backgroundColor: '#2E9E5B10', borderColor: '#2E9E5B33' }]}>
            <Text style={[styles.summaryLabel, { color: Colors.success }]}>{t(lang, 'strongest')}</Text>
            <Text style={styles.summaryCategory} numberOfLines={1}>{best.category}</Text>
            <Text style={[styles.summaryPct, { color: Colors.success }]}>{best.accuracy}%</Text>
          </View>
        </View>
      )}
      {stats.map((s) => {
        const color = s.accuracy >= 80 ? Colors.success : s.accuracy >= 60 ? '#B8860B' : Colors.danger;
        const barColor = s.accuracy >= 80 ? Colors.success : s.accuracy >= 60 ? Colors.yellow : Colors.danger;
        return (
          <View key={s.category} style={styles.statCard}>
            <View style={styles.statHeader}>
              <Text style={styles.statCategory} numberOfLines={1}>{s.category}</Text>
              <View style={[styles.statPill, { backgroundColor: barColor + '18' }]}>
                <Text style={[styles.statPct, { color }]}>{s.accuracy}%</Text>
              </View>
            </View>
            <View style={styles.progressBg}>
              <View style={[styles.progressBar, { width: `${s.accuracy}%` as any, backgroundColor: barColor }]} />
            </View>
            <View style={styles.statFooter}>
              <Text style={styles.statDetail}>{s.correct}/{s.total} {t(lang, 'questionsAnswered')}</Text>
              <Text style={styles.statDetail}>{s.tried} {t(lang, 'examsOf')} {s.examCount} exams</Text>
            </View>
          </View>
        );
      })}
    </View>
  );
}

export default function ProfileScreen() {
  const { exams, examsPassedCount, examsAttemptedCount, attempts, clearAllProgress, lang, setLang } = useApp();
  const [showConfirm, setShowConfirm] = useState(false);
  const totalExams = exams.length;
  const recent = attempts.slice(0, 10);

  function formatDate(iso: string) {
    return new Date(iso).toLocaleDateString(lang === 'pt-BR' ? 'pt-BR' : lang === 'es' ? 'es-MX' : 'en-CA', { month: 'short', day: 'numeric', year: 'numeric' });
  }

  function handleReset() {
    Alert.alert(
      t(lang, 'resetProgress'),
      t(lang, 'resetConfirm'),
      [
        { text: t(lang, 'cancel'), style: 'cancel' },
        { text: t(lang, 'reset'), style: 'destructive', onPress: () => clearAllProgress() },
      ]
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>{t(lang, 'myProgress')}</Text>

      {/* Stats hero */}
      <View style={styles.heroCard}>
        <View style={styles.heroAvatar}><Text style={{ fontSize: 28 }}>👤</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.heroText}>{examsPassedCount}/{totalExams} {t(lang, 'examsPassed')}</Text>
          <Text style={styles.heroSub}>{t(lang, 'allExamsUnlocked', { count: totalExams })}</Text>
        </View>
        <View style={{ alignItems: 'center' }}>
          <Text style={{ fontSize: 24 }}>🏆</Text>
          <Text style={styles.heroSub}>{examsAttemptedCount} {t(lang, 'attempted').toLowerCase()}</Text>
        </View>
      </View>

      {/* Stats grid */}
      <View style={styles.statsGrid}>
        {[
          { label: t(lang, 'attempted'), value: examsAttemptedCount, color: Colors.orange },
          { label: t(lang, 'passed'), value: examsPassedCount, color: Colors.success },
          { label: t(lang, 'remaining'), value: totalExams - examsPassedCount, color: Colors.teal },
        ].map((s) => (
          <View key={s.label} style={styles.statBox}>
            <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Category stats */}
      <Text style={styles.sectionTitle}>{t(lang, 'categoryStats')}</Text>
      <Text style={styles.sectionSub}>{t(lang, 'categoryStatsSubtitle')}</Text>
      <CategoryStats />

      {/* Language */}
      <Text style={[styles.sectionTitle, { marginTop: 20 }]}>{t(lang, 'language')}</Text>
      <View style={styles.langList}>
        {LANG_OPTIONS.map((opt) => {
          const isActive = lang === opt.code;
          return (
            <TouchableOpacity
              key={opt.code}
              style={[styles.langItem, isActive && styles.langItemActive]}
              onPress={() => setLang(opt.code as LangCode)}
              activeOpacity={0.7}
            >
              <Text style={styles.langFlag}>{opt.flag}</Text>
              <Text style={[styles.langLabel, isActive && { color: Colors.orange }]}>{opt.label}</Text>
              {isActive && <Text style={styles.langCheck}>✓</Text>}
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Recent attempts */}
      <Text style={[styles.sectionTitle, { marginTop: 20 }]}>{t(lang, 'recentAttempts')}</Text>
      {recent.length === 0 ? (
        <View style={styles.emptyAttempts}>
          <Text style={{ fontSize: 28 }}>📝</Text>
          <Text style={styles.emptyText}>{t(lang, 'noAttempts')}</Text>
        </View>
      ) : (
        recent.map((a, i) => (
          <View key={i} style={styles.attemptRow}>
            <Text style={{ fontSize: 18 }}>{a.passed ? '✅' : '❌'}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.attemptTitle}>{t(lang, 'practiceTest')} {a.examId}</Text>
              <Text style={styles.attemptDate}>{formatDate(a.completedAt)}</Text>
            </View>
            <View style={[styles.scorePill, { backgroundColor: a.passed ? '#2E9E5B18' : '#E0483E18' }]}>
              <Text style={[styles.scorePillText, { color: a.passed ? Colors.success : Colors.danger }]}>
                {a.score}/{a.totalQuestions}
              </Text>
            </View>
          </View>
        ))
      )}

      {/* Reset */}
      {attempts.length > 0 && (
        <TouchableOpacity style={styles.resetBtn} onPress={handleReset} activeOpacity={0.7}>
          <Text style={styles.resetBtnText}>🔄 {t(lang, 'resetProgress')}</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: 16, paddingBottom: 32 },
  title: { fontSize: 20, fontWeight: '900', color: Colors.textDark, marginBottom: 16 },
  sectionTitle: { fontSize: 15, fontWeight: '800', color: Colors.textDark, marginBottom: 4 },
  sectionSub: { fontSize: 11, fontWeight: '500', color: Colors.textMuted, marginBottom: 12 },

  heroCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    padding: 18, borderRadius: Radius.xl, marginBottom: 14,
    backgroundColor: Colors.orange,
    ...Shadow.hero,
  },
  heroAvatar: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center',
  },
  heroText: { color: 'white', fontSize: 15, fontWeight: '800' },
  heroSub: { color: 'rgba(255,255,255,0.8)', fontSize: 11, fontWeight: '600', marginTop: 2 },

  statsGrid: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  statBox: {
    flex: 1, backgroundColor: Colors.white, borderRadius: Radius.lg,
    padding: 12, alignItems: 'center', borderWidth: 1, borderColor: Colors.border,
  },
  statValue: { fontSize: 22, fontWeight: '900' },
  statLabel: { fontSize: 10, fontWeight: '600', color: Colors.textMuted, marginTop: 2 },

  // Category stats
  emptyStats: {
    backgroundColor: Colors.white, borderRadius: Radius.lg, padding: 16,
    alignItems: 'center', borderWidth: 1, borderColor: Colors.border, marginBottom: 8,
  },
  emptyStatsText: { fontSize: 12, fontWeight: '600', color: Colors.textMuted, textAlign: 'center' },
  summaryRow: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  summaryPill: {
    flex: 1, padding: 10, borderRadius: Radius.md, borderWidth: 1,
  },
  summaryLabel: { fontSize: 10, fontWeight: '700' },
  summaryCategory: { fontSize: 12, fontWeight: '800', color: Colors.textDark, marginTop: 2 },
  summaryPct: { fontSize: 16, fontWeight: '900', marginTop: 2 },
  statCard: {
    backgroundColor: Colors.white, borderRadius: Radius.lg, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: Colors.border,
  },
  statHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  statCategory: { fontSize: 13, fontWeight: '800', color: Colors.textDark, flex: 1 },
  statPill: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12 },
  statPct: { fontSize: 12, fontWeight: '900' },
  progressBg: { height: 6, borderRadius: 3, backgroundColor: Colors.border, marginBottom: 6 },
  progressBar: { height: 6, borderRadius: 3 },
  statFooter: { flexDirection: 'row', justifyContent: 'space-between' },
  statDetail: { fontSize: 10, fontWeight: '600', color: Colors.textMuted },

  // Language
  langList: { gap: 8, marginBottom: 4 },
  langItem: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    padding: 12, borderRadius: Radius.lg, backgroundColor: Colors.white,
    borderWidth: 1, borderColor: Colors.border,
  },
  langItemActive: { borderColor: Colors.orange, borderWidth: 2, backgroundColor: '#FF7A3C08' },
  langFlag: { fontSize: 22 },
  langLabel: { flex: 1, fontSize: 14, fontWeight: '700', color: Colors.textDark },
  langCheck: { fontSize: 16, color: Colors.orange, fontWeight: '900' },

  // Attempts
  emptyAttempts: { alignItems: 'center', paddingVertical: 24, gap: 8 },
  emptyText: { fontSize: 12, fontWeight: '600', color: Colors.textMuted },
  attemptRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.white, borderRadius: Radius.md, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: Colors.border,
  },
  attemptTitle: { fontSize: 13, fontWeight: '700', color: Colors.textDark },
  attemptDate: { fontSize: 11, fontWeight: '500', color: Colors.textMuted },
  scorePill: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12 },
  scorePillText: { fontSize: 12, fontWeight: '800' },

  // Reset
  resetBtn: {
    marginTop: 16, padding: 14, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: '#E0483E44', backgroundColor: '#E0483E08',
    alignItems: 'center',
  },
  resetBtnText: { fontSize: 13, fontWeight: '700', color: Colors.danger },
});
