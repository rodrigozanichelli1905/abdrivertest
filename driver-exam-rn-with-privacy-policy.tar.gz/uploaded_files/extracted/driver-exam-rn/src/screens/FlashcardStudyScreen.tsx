// Driver Exam Prep – Flashcard Study Screen (React Native)

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Animated,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { Colors, Radius, Shadow } from '../components/theme';
import type { Question } from '../types';

export default function FlashcardStudyScreen() {
  const { lang } = useApp();
  const navigation = useNavigation();
  const route = useRoute<any>();
  const questions: Question[] = JSON.parse(route.params?.questionsData ?? '[]');
  const title: string = route.params?.title ?? '';

  const [currentIndex, setCurrentIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<Set<number>>(new Set());
  const [reviewing, setReviewing] = useState<'all' | 'unknown'>('all');
  const [sessionComplete, setSessionComplete] = useState(false);

  const activeCards = reviewing === 'unknown'
    ? questions.filter((_, i) => !known.has(i))
    : questions;

  const current = activeCards[currentIndex] ?? null;
  const total = activeCards.length;
  const progress = total > 0 ? (currentIndex + 1) / total : 0;
  const knownCount = known.size;
  const unknownCount = questions.length - knownCount;

  function advance(currentKnown: Set<number>) {
    setFlipped(false);
    const nextIndex = currentIndex + 1;
    const remaining = reviewing === 'unknown'
      ? questions.filter((_, i) => !currentKnown.has(i))
      : questions;
    if (nextIndex >= remaining.length) {
      setSessionComplete(true);
    } else {
      setCurrentIndex(nextIndex);
    }
  }

  function markKnown() {
    const origIdx = questions.indexOf(current!);
    const next = new Set(known);
    next.add(origIdx);
    setKnown(next);
    advance(next);
  }

  function markUnknown() { advance(known); }

  function restart() {
    setCurrentIndex(0); setFlipped(false); setSessionComplete(false);
  }

  function reviewUnknown() {
    setKnown(new Set()); setCurrentIndex(0); setFlipped(false);
    setSessionComplete(false); setReviewing('unknown');
  }

  if (sessionComplete) {
    return (
      <View style={styles.completeContainer}>
        <View style={styles.completeIcon}><Text style={{ fontSize: 40 }}>📚</Text></View>
        <Text style={styles.completeTitle}>{t(lang, 'sessionDone')}</Text>
        <Text style={styles.completeSub}>{t(lang, 'reviewedCards', { count: questions.length })}</Text>
        <View style={styles.completeStats}>
          <View style={[styles.completeStat, { backgroundColor: '#2E9E5B10', borderColor: '#2E9E5B44' }]}>
            <Text style={[styles.completeStatNum, { color: Colors.success }]}>{knownCount}</Text>
            <Text style={styles.completeStatLabel}>{t(lang, 'gotItCount')}</Text>
          </View>
          <View style={[styles.completeStat, { backgroundColor: '#E0483E10', borderColor: '#E0483E44' }]}>
            <Text style={[styles.completeStatNum, { color: Colors.danger }]}>{unknownCount}</Text>
            <Text style={styles.completeStatLabel}>{t(lang, 'needReview')}</Text>
          </View>
        </View>
        {unknownCount > 0 && (
          <TouchableOpacity style={styles.reviewMissedBtn} onPress={reviewUnknown} activeOpacity={0.8}>
            <Text style={styles.reviewMissedBtnText}>🔄 {t(lang, 'reviewMissed', { count: unknownCount })}</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity style={styles.restartBtn} onPress={restart} activeOpacity={0.7}>
          <Text style={styles.restartBtnText}>{t(lang, 'restartAll')}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()} activeOpacity={0.7}>
          <Text style={styles.backBtnText}>{t(lang, 'backToResults')}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!current) return null;

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>{t(lang, 'flashcardStudy')}</Text>
          <Text style={styles.headerSub}>{title} · {currentIndex + 1}/{total}</Text>
        </View>
        <View style={styles.knownPill}>
          <Text style={styles.knownPillText}>{knownCount} {t(lang, 'known')}</Text>
        </View>
      </View>

      {/* Progress */}
      <View style={styles.progressBg}>
        <View style={[styles.progressBar, { width: `${progress * 100}%` as any }]} />
      </View>

      {/* Card */}
      <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.cardArea}>
        <TouchableOpacity
          style={[styles.card, flipped && styles.cardFlipped]}
          onPress={() => setFlipped((f) => !f)}
          activeOpacity={0.9}
        >
          {!flipped ? (
            <View style={styles.cardFront}>
              <View style={styles.questionPill}>
                <Text style={styles.questionPillText}>{t(lang, 'question')}</Text>
              </View>
              <Text style={styles.cardQuestion}>{current.text}</Text>
              <Text style={styles.tapHint}>👆 {t(lang, 'tapToRevealAnswer')}</Text>
            </View>
          ) : (
            <View style={styles.cardBack}>
              <View style={styles.answerPill}>
                <Text style={styles.answerPillText}>{t(lang, 'answer')}</Text>
              </View>
              <Text style={styles.cardAnswer}>{current.options[current.correct]}</Text>
              {current.explanation ? (
                <View style={styles.explanationBox}>
                  <Text style={styles.explanationText}>{current.explanation}</Text>
                </View>
              ) : null}
            </View>
          )}
        </TouchableOpacity>

        {/* Options (visible when flipped) */}
        {flipped && (
          <View style={styles.optionsList}>
            <Text style={styles.optionsTitle}>{t(lang, 'allOptions')}</Text>
            {current.options.map((opt, i) => {
              const isCorrect = i === current.correct;
              return (
                <View key={i} style={[styles.optionItem, isCorrect && styles.optionItemCorrect]}>
                  <Text style={[styles.optionText, isCorrect && { color: Colors.success }]}>
                    {String.fromCharCode(65 + i)}. {opt}{isCorrect ? ' ✓' : ''}
                  </Text>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>

      {/* Action buttons */}
      <View style={styles.actionRow}>
        <TouchableOpacity style={styles.stillLearningBtn} onPress={markUnknown} activeOpacity={0.7}>
          <Text style={styles.stillLearningText}>❌ {t(lang, 'stillLearning')}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.gotItBtn} onPress={markKnown} activeOpacity={0.8}>
          <Text style={styles.gotItText}>✅ {t(lang, 'gotIt')}</Text>
        </TouchableOpacity>
      </View>

      {/* Nav */}
      <View style={styles.navRow}>
        <TouchableOpacity
          disabled={currentIndex === 0}
          onPress={() => { setCurrentIndex((i) => i - 1); setFlipped(false); }}
          style={{ opacity: currentIndex === 0 ? 0.3 : 1 }}
        >
          <Text style={styles.navText}>← {t(lang, 'prev')}</Text>
        </TouchableOpacity>
        <Text style={styles.navCount}>{currentIndex + 1} {t(lang, 'of')} {total}</Text>
        <TouchableOpacity
          disabled={currentIndex >= total - 1}
          onPress={() => { setCurrentIndex((i) => i + 1); setFlipped(false); }}
          style={{ opacity: currentIndex >= total - 1 ? 0.3 : 1 }}
        >
          <Text style={styles.navText}>{t(lang, 'next')} →</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingBottom: 8 },
  headerTitle: { fontSize: 14, fontWeight: '800', color: Colors.textDark },
  headerSub: { fontSize: 11, fontWeight: '600', color: Colors.textMuted },
  knownPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, backgroundColor: '#2E9E5B18' },
  knownPillText: { fontSize: 11, fontWeight: '700', color: Colors.success },
  progressBg: { height: 4, backgroundColor: Colors.border, marginHorizontal: 16, borderRadius: 2, marginBottom: 12 },
  progressBar: { height: 4, borderRadius: 2, backgroundColor: Colors.orange },
  cardArea: { padding: 16, paddingBottom: 8 },
  card: {
    borderRadius: Radius.xxl, padding: 22, minHeight: 200,
    backgroundColor: Colors.white, borderWidth: 1, borderColor: Colors.border,
    ...Shadow.card,
  },
  cardFlipped: {
    backgroundColor: Colors.teal, borderColor: Colors.teal,
  },
  cardFront: { flex: 1 },
  cardBack: { flex: 1 },
  questionPill: {
    alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: 12, backgroundColor: '#FF7A3C18', marginBottom: 12,
  },
  questionPillText: { fontSize: 11, fontWeight: '700', color: Colors.orange },
  cardQuestion: { fontSize: 15, fontWeight: '700', color: Colors.textDark, lineHeight: 22, flex: 1 },
  tapHint: { marginTop: 16, fontSize: 11, fontWeight: '600', color: Colors.textMuted, textAlign: 'center' },
  answerPill: {
    alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.2)', marginBottom: 10,
  },
  answerPillText: { fontSize: 11, fontWeight: '700', color: 'white' },
  cardAnswer: { fontSize: 16, fontWeight: '800', color: 'white', lineHeight: 24 },
  explanationBox: { marginTop: 12, padding: 10, borderRadius: Radius.sm, backgroundColor: 'rgba(255,255,255,0.15)' },
  explanationText: { fontSize: 11, fontWeight: '500', color: 'rgba(255,255,255,0.85)', lineHeight: 16 },
  optionsList: { marginTop: 12, gap: 6 },
  optionsTitle: { fontSize: 11, fontWeight: '700', color: Colors.textMuted, marginBottom: 4 },
  optionItem: {
    padding: 10, borderRadius: Radius.sm, backgroundColor: Colors.white,
    borderWidth: 1, borderColor: Colors.border,
  },
  optionItemCorrect: { backgroundColor: '#2E9E5B10', borderColor: Colors.success },
  optionText: { fontSize: 11, fontWeight: '600', color: Colors.textMuted },
  actionRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, paddingBottom: 8 },
  stillLearningBtn: {
    flex: 1, padding: 14, borderRadius: Radius.lg, alignItems: 'center',
    borderWidth: 1, borderColor: '#E0483E44', backgroundColor: '#E0483E08',
  },
  stillLearningText: { fontSize: 13, fontWeight: '700', color: Colors.danger },
  gotItBtn: {
    flex: 1, padding: 14, borderRadius: Radius.lg, alignItems: 'center',
    backgroundColor: Colors.success,
  },
  gotItText: { fontSize: 13, fontWeight: '700', color: 'white' },
  navRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 16, paddingBottom: 12,
  },
  navText: { fontSize: 12, fontWeight: '700', color: Colors.textMuted },
  navCount: { fontSize: 11, fontWeight: '600', color: Colors.textMuted },

  // Complete screen
  completeContainer: { flex: 1, backgroundColor: Colors.background, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  completeIcon: { width: 80, height: 80, borderRadius: 24, backgroundColor: Colors.orange, alignItems: 'center', justifyContent: 'center' },
  completeTitle: { fontSize: 24, fontWeight: '900', color: Colors.textDark },
  completeSub: { fontSize: 13, fontWeight: '600', color: Colors.textMuted },
  completeStats: { flexDirection: 'row', gap: 12, width: '100%' },
  completeStat: { flex: 1, padding: 14, borderRadius: Radius.lg, borderWidth: 1, alignItems: 'center' },
  completeStatNum: { fontSize: 24, fontWeight: '900' },
  completeStatLabel: { fontSize: 11, fontWeight: '600', color: Colors.textMuted, marginTop: 2 },
  reviewMissedBtn: {
    width: '100%', padding: 14, borderRadius: Radius.lg, alignItems: 'center',
    backgroundColor: Colors.orange, ...Shadow.hero,
  },
  reviewMissedBtnText: { fontSize: 14, fontWeight: '700', color: 'white' },
  restartBtn: {
    width: '100%', padding: 13, borderRadius: Radius.lg, alignItems: 'center',
    borderWidth: 1, borderColor: '#FF7A3C44', backgroundColor: '#FF7A3C08',
  },
  restartBtnText: { fontSize: 13, fontWeight: '700', color: Colors.orange },
  backBtn: {
    width: '100%', padding: 13, borderRadius: Radius.lg, alignItems: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  backBtnText: { fontSize: 13, fontWeight: '700', color: Colors.textMuted },
});
