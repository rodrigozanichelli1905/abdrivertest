// Driver Exam Prep – Road Signs Screen (React Native)

import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { Colors, Radius } from '../components/theme';
import type { LangCode } from '../types';

interface SignInfo {
  shape: string;
  meaning: string;
  description: string;
  color: string;
  emoji: string;
}

function getSigns(lang: LangCode): SignInfo[] {
  const isEs = lang === 'es';
  const isPt = lang === 'pt-BR';
  return [
    {
      shape: isEs ? 'Octágono' : isPt ? 'Octógono' : 'Octagon',
      meaning: 'STOP',
      description: isEs
        ? 'Requiere detenerse completamente antes de continuar. Detente en la línea de parada o antes del cruce peatonal.'
        : isPt
        ? 'Exige parada completa antes de prosseguir. Pare na linha de parada ou antes da faixa de pedestres.'
        : 'Requires a complete stop before proceeding. Stop at the marked stop line or before the crosswalk.',
      color: Colors.danger, emoji: '🛑',
    },
    {
      shape: isEs ? 'Triángulo invertido' : isPt ? 'Triângulo invertido' : 'Inverted Triangle',
      meaning: 'YIELD',
      description: isEs
        ? 'Reduce la velocidad y cede el paso al tráfico. Detente si es necesario.'
        : isPt
        ? 'Reduza a velocidade e dê preferência ao tráfego. Pare se necessário.'
        : 'Slow down and give right-of-way to traffic. Stop if necessary.',
      color: Colors.deepOrange, emoji: '⚠️',
    },
    {
      shape: isEs ? 'Diamante' : isPt ? 'Losango' : 'Diamond',
      meaning: isEs ? 'Advertencia' : isPt ? 'Aviso' : 'Warning',
      description: isEs
        ? 'Señales amarillas/naranjas que advierten sobre peligros o condiciones cambiantes en la carretera.'
        : isPt
        ? 'Placas amarelas/laranja que avisam sobre perigos ou condições de estrada em mudança.'
        : 'Yellow/orange signs warning of hazards or changing road conditions ahead.',
      color: Colors.yellow, emoji: '🔶',
    },
    {
      shape: isEs ? 'Rectángulo' : isPt ? 'Retângulo' : 'Rectangle',
      meaning: isEs ? 'Regulatoria' : isPt ? 'Regulatória' : 'Regulatory',
      description: isEs
        ? 'Dan instrucciones que deben seguirse: límites de velocidad, restricciones de giro.'
        : isPt
        ? 'Fornecem instruções que devem ser seguidas: limites de velocidade, restrições de conversão.'
        : 'Give instructions that must be followed: speed limits, turn restrictions.',
      color: Colors.teal, emoji: '🔲',
    },
    {
      shape: isEs ? 'Círculo con X' : isPt ? 'Círculo com X' : 'Round with X',
      meaning: isEs ? 'Cruce Ferroviario' : isPt ? 'Passagem de Nível' : 'Railway Crossing',
      description: isEs
        ? 'Advierte de un cruce ferroviario. Reduce la velocidad y prepárate para detenerte.'
        : isPt
        ? 'Avisa sobre uma passagem de nível. Reduza a velocidade e esteja preparado para parar.'
        : 'Warns of a railway crossing ahead. Slow down and be prepared to stop for trains.',
      color: Colors.orange, emoji: '🚂',
    },
    {
      shape: isEs ? 'Pentágono' : isPt ? 'Pentágono' : 'Pentagon',
      meaning: isEs ? 'Zona Escolar' : isPt ? 'Zona Escolar' : 'School Zone',
      description: isEs
        ? 'Indica una zona escolar. Reduce la velocidad y vigila a los niños.'
        : isPt
        ? 'Indica uma zona escolar. Reduza a velocidade e fique atento às crianças.'
        : 'Indicates a school zone. Reduce speed and watch for children.',
      color: Colors.deepTeal, emoji: '🏫',
    },
    {
      shape: isEs ? 'Diamante naranja' : isPt ? 'Losango laranja' : 'Orange Diamond',
      meaning: isEs ? 'Zona de Construcción' : isPt ? 'Zona de Obras' : 'Construction Zone',
      description: isEs
        ? 'Indica zonas de construcción. Las multas se duplican. Vigila a los trabajadores.'
        : isPt
        ? 'Indica zonas de obras. As multas são dobradas. Fique atento a trabalhadores.'
        : 'Construction or maintenance zones. Fines doubled. Watch for workers and equipment.',
      color: Colors.deepOrange, emoji: '🚧',
    },
    {
      shape: isEs ? 'Rectángulo verde' : isPt ? 'Retângulo verde' : 'Rectangle (Green)',
      meaning: isEs ? 'Guía / Información' : isPt ? 'Orientação' : 'Guide / Information',
      description: isEs
        ? 'Señales verdes con distancias a destinos, números de rutas e información de salidas.'
        : isPt
        ? 'Placas verdes com distâncias a destinos, números de rotas e informações de saídas.'
        : 'Green signs with distances to destinations, highway route numbers, and exit information.',
      color: Colors.success, emoji: '🟢',
    },
  ];
}

export default function SignsScreen() {
  const { lang } = useApp();
  const signs = getSigns(lang);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>{t(lang, 'roadSignsGuide')}</Text>
      <Text style={styles.subtitle}>{t(lang, 'roadSignsSubtitle')}</Text>

      {signs.map((sign) => (
        <View key={sign.meaning} style={styles.card}>
          <View style={[styles.iconBox, { backgroundColor: sign.color }]}>
            <Text style={{ fontSize: 22 }}>{sign.emoji}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <View style={styles.cardHeader}>
              <Text style={styles.cardMeaning}>{sign.meaning}</Text>
              <View style={[styles.shapePill, { backgroundColor: sign.color + '18' }]}>
                <Text style={[styles.shapePillText, { color: sign.color }]}>{sign.shape}</Text>
              </View>
            </View>
            <Text style={styles.cardDesc}>{sign.description}</Text>
          </View>
        </View>
      ))}

      <View style={styles.disclaimer}>
        <Text style={styles.disclaimerText}>
          <Text style={{ fontWeight: '700', color: Colors.textDark }}>{t(lang, 'signDisclaimer')} </Text>
          {t(lang, 'signDisclaimerBody')}
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: 16, paddingBottom: 32 },
  title: { fontSize: 20, fontWeight: '900', color: Colors.textDark, marginBottom: 4 },
  subtitle: { fontSize: 13, fontWeight: '500', color: Colors.textMuted, marginBottom: 16 },
  card: {
    flexDirection: 'row', gap: 12, backgroundColor: Colors.white,
    borderRadius: Radius.lg, padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: Colors.border,
  },
  iconBox: {
    width: 48, height: 48, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  cardMeaning: { fontSize: 13, fontWeight: '800', color: Colors.textDark },
  shapePill: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10 },
  shapePillText: { fontSize: 10, fontWeight: '700' },
  cardDesc: { fontSize: 11, fontWeight: '500', color: Colors.textMuted, lineHeight: 16 },
  disclaimer: {
    marginTop: 8, padding: 14, borderRadius: Radius.lg,
    backgroundColor: '#FFC94A18', borderWidth: 1, borderColor: '#FFC94A44',
  },
  disclaimerText: { fontSize: 11, fontWeight: '600', color: Colors.textMuted, lineHeight: 16 },
});
