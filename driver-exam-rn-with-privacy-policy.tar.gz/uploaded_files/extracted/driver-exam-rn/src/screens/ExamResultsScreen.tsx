// Driver Exam Prep – Exam Results Screen (React Native)

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useApp } from '../context/AppContext';
import { useExamSession } from '../context/ExamSessionContext';
import { t } from '../i18n';
import { Colors, Radius, Shadow } from '../components/theme';
import type { RootStackParamList, ExamAttempt, Question } from '../types';

type NavProp = NativeStackNavigationProp<RootStackParamList>;

function ReviewCard({ index, question, attempt }: { index: number; question: Question; attempt: ExamAttempt }) {
  const [expanded, setExpanded] = useState(false);
  const { lang } = useApp();
  const selected = attempt.answers[question.id];
  const isCorrect = selected === question.correct;
  const color = isCorrect ? Colors.success : Colors.danger;

  return (
    <TouchableOpacity
      style={styles.reviewCard}
      onPress={() => setExpanded((e) => !e)}
      activeOpacity={0.8}
    >
      <View style={styles.reviewHeader}>
        <Text style={{ fontSize: 16 }}>{isCorrect ? '✅' : '❌'}</Text>
        <Text style={styles.reviewQ} numberOfLines={expanded ? undefined : 2}>
          Q{index}. {question.text}
        </Text>
        <Text style={{ color: Colors.textMuted }}>{expanded ? '▲' : '▼'}</Text>
      </View>
      {expanded && (
        <View style={styles.reviewBody}>
          {question.options.map((opt, i) => {
            const isThisCorrect = i === question.correct;
            const isThisSelected = i === selected;
            let bg = 'transparent';
            let border = Colors.border;
            let textColor = Colors.textDark;
            if (isThisCorrect) { bg = '#2E9E5B10'; border = Colors.success; textColor = Colors.success; }
            else if (isThisSelected) { bg = '#E0483E10'; border = Colors.danger; textColor = Colors.danger; }
            return (
              <View key={i} style={[styles.reviewOption, { backgroundColor: bg, borderColor: border }]}>
                <Text style={[styles.reviewOptionText, { color: textColor }]}>
                  {String.fromCharCode(65 + i)}. {opt}
                  {isThisCorrect ? ' ✓' : isThisSelected ? ' ✗' : ''}
                </Text>
              </View>
            );
          })}
          {question.explanation ? (
            <View style={styles.explanationBox}>
              <Text style={styles.explanationText}>
                <Text style={{ fontWeight: '700', color: Colors.textDark }}>{t(lang, 'explanation')} </Text>
                {question.explanation}
              </Text>
            </View>
          ) : null}
        </View>
      )}
    </TouchableOpacity>
  );
}

export default function ExamResultsScreen() {
  const { exams, lang } = useApp();
  const session = useExamSession();
  const navigation = useNavigation<NavProp>();
  const route = useRoute<any>();
  const examId: number = route.params?.examId;
  const attempt: ExamAttempt = JSON.parse(route.params?.attemptData ?? '{}');

  const exam = exams.find((e) => e.id === examId);
  if (!exam) return null;

  const passed = attempt.passed;
  const pct = Math.round((attempt.score / attempt.totalQuestions) * 100);
  const wrong = attempt.totalQuestions - attempt.score;

  const wrongQuestions = exam.questions.filter((q) => {
    const sel = attempt.answers[q.id];
    return sel === undefined || sel !== q.correct;
  });

  function handleRetake() {
    session.startExam(exam!);
    navigation.replace('ExamTaking', { examId });
  }

  function handleFlashcards() {
    navigation.navigate('FlashcardStudy', {
      questionsData: JSON.stringify(wrongQuestions),
      title: `${t(lang, 'practiceTest')} ${exam!.id}`,
    });
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Score card */}
      <View style={[styles.scoreCard, { backgroundColor: passed ? Colors.success : Colors.danger }]}>
        <View style={styles.scoreCardDec} />
        <Text style={styles.scoreNum}>{attempt.score}</Text>
        <Text style={styles.scoreOf}>{t(lang, 'outOf')} {attempt.totalQuestions} · {pct}%</Text>
        <View style={styles.scoreBadge}>
          <Text style={styles.scoreBadgeText}>
            {passed ? `${t(lang, 'passed').toUpperCase()}!` : t(lang, 'failed')}
          </Text>
        </View>
        {!passed && (
          <Text style={styles.scoreHint}>Need 25+ to pass. {25 - attempt.score} more needed.</Text>
        )}
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        {[
          { label: t(lang, 'correct'), value: attempt.score, color: Colors.success },
          { label: t(lang, 'wrong'), value: wrong, color: Colors.danger },
          { label: t(lang, 'score'), value: `${pct}%`, color: Colors.orange },
        ].map((s) => (
          <View key={s.label} style={styles.statBox}>
            <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Action buttons */}
      <View style={styles.actionRow}>
        <TouchableOpacity style={styles.retakeBtn} onPress={handleRetake} activeOpacity={0.7}>
          <Text style={styles.retakeBtnText}>🔄 {t(lang, 'retake')}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.popToTop()} activeOpacity={0.8}>
          <Text style={styles.backBtnText}>{t(lang, 'backToExams')}</Text>
        </TouchableOpacity>
      </View>

      {/* Flashcard button */}
      {wrongQuestions.length > 0 && (
        <TouchableOpacity style={styles.flashcardBtn} onPress={handleFlashcards} activeOpacity={0.8}>
          <Text style={styles.flashcardBtnText}>
            📚 {t(lang, 'studyMissedCards', { count: wrongQuestions.length })}
          </Text>
        </TouchableOpacity>
      )}

      {/* Review */}
      <Text style={styles.reviewTitle}>{t(lang, 'reviewAllAnswers')}</Text>
      {exam.questions.map((q, i) => (
        <ReviewCard key={q.id} index={i + 1} question={q} attempt={attempt} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: 16, paddingBottom: 32 },
  scoreCard: {
    borderRadius: Radius.xxl, padding: 24, alignItems: 'center',
    marginBottom: 16, overflow: 'hidden', ...Shadow.hero,
  },
  scoreCardDec: {
    position: 'absolute', top: -30, right: -30,
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  scoreNum: { color: 'white', fontSize: 64, fontWeight: '900', lineHeight: 72 },
  scoreOf: { color: 'rgba(255,255,255,0.8)', fontSize: 14, fontWeight: '600', marginBottom: 10 },
  scoreBadge: {
    paddingHorizontal: 16, paddingVertical: 6, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  scoreBadgeText: { color: 'white', fontSize: 16, fontWeight: '800' },
  scoreHint: { color: 'rgba(255,255,255,0.7)', fontSize: 11, marginTop: 8 },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  statBox: {
    flex: 1, backgroundColor: Colors.white, borderRadius: Radius.lg,
    padding: 12, alignItems: 'center', borderWidth: 1, borderColor: Colors.border,
  },
  statValue: { fontSize: 20, fontWeight: '900' },
  statLabel: { fontSize: 10, fontWeight: '600', color: Colors.textMuted, marginTop: 2 },
  actionRow: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  retakeBtn: {
    flex: 1, padding: 13, borderRadius: Radius.lg, alignItems: 'center',
    borderWidth: 1, borderColor: '#FF7A3C44', backgroundColor: '#FF7A3C08',
  },
  retakeBtnText: { fontSize: 13, fontWeight: '700', color: Colors.orange },
  backBtn: {
    flex: 1, padding: 13, borderRadius: Radius.lg, alignItems: 'center',
    backgroundColor: Colors.orange,
  },
  backBtnText: { fontSize: 13, fontWeight: '700', color: 'white' },
  flashcardBtn: {
    padding: 14, borderRadius: Radius.lg, alignItems: 'center',
    backgroundColor: Colors.teal, marginBottom: 20, ...Shadow.card,
  },
  flashcardBtnText: { fontSize: 13, fontWeight: '700', color: 'white' },
  reviewTitle: { fontSize: 15, fontWeight: '800', color: Colors.textDark, marginBottom: 10 },
  reviewCard: {
    backgroundColor: Colors.white, borderRadius: Radius.lg, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: Colors.border,
  },
  reviewHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  reviewQ: { flex: 1, fontSize: 12, fontWeight: '700', color: Colors.textDark, lineHeight: 18 },
  reviewBody: { marginTop: 10, gap: 6 },
  reviewOption: {
    padding: 10, borderRadius: Radius.sm, borderWidth: 1,
  },
  reviewOptionText: { fontSize: 11, fontWeight: '600', lineHeight: 16 },
  explanationBox: {
    padding: 10, borderRadius: Radius.sm,
    backgroundColor: '#FFC94A18',
  },
  explanationText: { fontSize: 11, fontWeight: '500', color: Colors.textMuted, lineHeight: 16 },
});
