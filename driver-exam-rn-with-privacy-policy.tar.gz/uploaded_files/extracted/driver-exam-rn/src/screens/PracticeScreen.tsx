// Driver Exam Prep – Practice Screen (React Native)

import React from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { Colors, Radius, Shadow } from '../components/theme';
import type { RootStackParamList } from '../types';

type NavProp = NativeStackNavigationProp<RootStackParamList>;

export default function PracticeScreen() {
  const { exams, getBestAttempt, lang } = useApp();
  const navigation = useNavigation<NavProp>();
  const route = useRoute<any>();
  const categoryFilters: string[] | undefined = route.params?.categoryFilters;

  const filtered = categoryFilters
    ? exams.filter((e) =>
        categoryFilters.some((f) => e.category.toLowerCase().includes(f.toLowerCase()))
      )
    : exams;

  return (
    <View style={styles.container}>
      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View style={styles.header}>
            <Text style={styles.title}>{t(lang, 'allPracticeExams')}</Text>
            {categoryFilters && (
              <View style={styles.filterRow}>
                <View style={styles.filterPill}>
                  <Text style={styles.filterPillText}>{t(lang, 'filteredByCategory')}</Text>
                </View>
                <Text style={styles.filterCount}>{filtered.length} exams</Text>
              </View>
            )}
          </View>
        }
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>📚</Text>
            <Text style={styles.emptyText}>{t(lang, 'noExamsFound')}</Text>
          </View>
        }
        renderItem={({ item, index }) => {
          const best = getBestAttempt(item.id);
          const isPassed = best && best.score >= 25;
          const grad = index % 2 === 0 ? Colors.orange : Colors.teal;
          return (
            <TouchableOpacity
              style={styles.examCard}
              onPress={() => navigation.navigate('ExamIntro', { examId: item.id })}
              activeOpacity={0.7}
            >
              <View style={[styles.examBadge, { backgroundColor: grad }]}>
                <Text style={styles.examBadgeText}>#{item.id}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.examTitle}>{t(lang, 'practiceTest')} {item.id}</Text>
                <Text style={styles.examSub}>{item.questions.length} {t(lang, 'questions')} · {item.category}</Text>
              </View>
              {best ? (
                <View style={{ alignItems: 'flex-end' }}>
                  <View style={[styles.scorePill, { backgroundColor: isPassed ? '#2E9E5B18' : '#E0483E18' }]}>
                    <Text style={[styles.scorePillText, { color: isPassed ? Colors.success : Colors.danger }]}>
                      {best.score}/{item.questions.length}
                    </Text>
                  </View>
                  <Text style={[styles.examStatus, { color: isPassed ? Colors.success : Colors.danger }]}>
                    {isPassed ? t(lang, 'passed') : t(lang, 'failed')}
                  </Text>
                </View>
              ) : (
                <Text style={styles.notTried}>{t(lang, 'notTried')}</Text>
              )}
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  list: { padding: 16, paddingBottom: 24 },
  header: { marginBottom: 12 },
  title: { fontSize: 20, fontWeight: '900', color: Colors.textDark, marginBottom: 8 },
  filterRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  filterPill: {
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20,
    backgroundColor: '#FF7A3C18',
  },
  filterPillText: { fontSize: 11, fontWeight: '700', color: Colors.orange },
  filterCount: { fontSize: 11, fontWeight: '600', color: Colors.textMuted },
  empty: { alignItems: 'center', paddingVertical: 48, gap: 8 },
  emptyIcon: { fontSize: 36 },
  emptyText: { fontSize: 13, fontWeight: '600', color: Colors.textMuted },
  examCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: Colors.white, borderRadius: Radius.lg,
    padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: Colors.border,
    ...Shadow.card,
  },
  examBadge: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  examBadgeText: { color: 'white', fontWeight: '900', fontSize: 13 },
  examTitle: { fontSize: 13, fontWeight: '800', color: Colors.textDark },
  examSub: { fontSize: 11, fontWeight: '600', color: Colors.textMuted, marginTop: 2 },
  scorePill: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 20 },
  scorePillText: { fontSize: 11, fontWeight: '800' },
  examStatus: { fontSize: 10, fontWeight: '600', marginTop: 2 },
  notTried: { fontSize: 10, fontWeight: '600', color: Colors.textMuted },
});
