// Driver Exam Prep – Exam Intro Screen (React Native)

import React from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useApp } from '../context/AppContext';
import { useExamSession } from '../context/ExamSessionContext';
import { t } from '../i18n';
import { Colors, Radius, Shadow } from '../components/theme';
import type { RootStackParamList } from '../types';

type NavProp = NativeStackNavigationProp<RootStackParamList>;

export default function ExamIntroScreen() {
  const { exams, getBestAttempt, getAttemptsForExam, lang } = useApp();
  const session = useExamSession();
  const navigation = useNavigation<NavProp>();
  const route = useRoute<any>();
  const examId: number = route.params?.examId;

  const exam = exams.find((e) => e.id === examId);
  if (!exam) return null;

  const best = getBestAttempt(examId);
  const allAttempts = getAttemptsForExam(examId);
  const passed = best && best.score >= 25;
  const grad = (examId - 1) % 2 === 0 ? Colors.orange : Colors.teal;

  function handleStart() {
    session.startExam(exam!);
    navigation.navigate('ExamTaking', { examId });
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Exam card */}
      <View style={[styles.examCard, { backgroundColor: grad }]}>
        <View style={styles.examCardDec} />
        <View style={[styles.categoryPill, { backgroundColor: 'rgba(255,255,255,0.2)' }]}>
          <Text style={styles.categoryPillText}>{exam.category}</Text>
        </View>
        <Text style={styles.examCardTitle}>{t(lang, 'practiceTest')} {exam.id}</Text>
        <Text style={styles.examCardSub}>{exam.title}</Text>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        {[
          { label: t(lang, 'questions'), value: String(exam.questions.length) },
          { label: t(lang, 'noTimeLimit'), value: t(lang, 'unlimited') },
          { label: t(lang, 'passScore'), value: '25/30' },
        ].map((s) => (
          <View key={s.label} style={styles.statBox}>
            <Text style={styles.statValue}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Best score */}
      {best && (
        <View style={[styles.bestScore, { backgroundColor: passed ? '#2E9E5B10' : '#E0483E10', borderColor: passed ? '#2E9E5B44' : '#E0483E44' }]}>
          <Text style={{ fontSize: 18 }}>{passed ? '✅' : '❌'}</Text>
          <View>
            <Text style={styles.bestScoreText}>{t(lang, 'bestScore')} {best.score}/{best.totalQuestions}</Text>
            <Text style={styles.bestScoreSub}>
              {allAttempts.length} {t(lang, 'attempts')}{allAttempts.length !== 1 ? 's' : ''} · {passed ? t(lang, 'passed') + ' ✓' : t(lang, 'failed')}
            </Text>
          </View>
        </View>
      )}

      {/* How it works */}
      <View style={styles.howCard}>
        <Text style={styles.howTitle}>{t(lang, 'howItWorks')}</Text>
        {[t(lang, 'howItWorks1'), t(lang, 'howItWorks2'), t(lang, 'howItWorks3'), t(lang, 'howItWorks4'), t(lang, 'howItWorks5')].map((item) => (
          <View key={item} style={styles.howItem}>
            <View style={styles.howDot} />
            <Text style={styles.howText}>{item}</Text>
          </View>
        ))}
      </View>

      {/* Start button */}
      <TouchableOpacity style={[styles.startBtn, { backgroundColor: grad }]} onPress={handleStart} activeOpacity={0.8}>
        <Text style={styles.startBtnText}>▶  {best ? t(lang, 'retakeExam') : t(lang, 'startExam')}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: 16, paddingBottom: 32 },
  examCard: {
    borderRadius: Radius.xxl, padding: 22, marginBottom: 16,
    overflow: 'hidden', ...Shadow.hero,
  },
  examCardDec: {
    position: 'absolute', top: -30, right: -30,
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  categoryPill: {
    alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4,
    borderRadius: 20, marginBottom: 10,
  },
  categoryPillText: { color: 'white', fontSize: 11, fontWeight: '700' },
  examCardTitle: { color: 'white', fontSize: 22, fontWeight: '900', marginBottom: 4 },
  examCardSub: { color: 'rgba(255,255,255,0.8)', fontSize: 13, fontWeight: '600' },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  statBox: {
    flex: 1, backgroundColor: Colors.white, borderRadius: Radius.lg,
    padding: 12, alignItems: 'center', borderWidth: 1, borderColor: Colors.border,
  },
  statValue: { fontSize: 13, fontWeight: '800', color: Colors.textDark },
  statLabel: { fontSize: 10, fontWeight: '600', color: Colors.textMuted, marginTop: 2, textAlign: 'center' },
  bestScore: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    padding: 14, borderRadius: Radius.lg, borderWidth: 1, marginBottom: 14,
  },
  bestScoreText: { fontSize: 13, fontWeight: '800', color: Colors.textDark },
  bestScoreSub: { fontSize: 11, fontWeight: '600', color: Colors.textMuted, marginTop: 2 },
  howCard: {
    backgroundColor: Colors.white, borderRadius: Radius.lg, padding: 14,
    borderWidth: 1, borderColor: Colors.border, marginBottom: 20,
  },
  howTitle: { fontSize: 13, fontWeight: '800', color: Colors.textDark, marginBottom: 10 },
  howItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 6 },
  howDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.orange, marginTop: 5 },
  howText: { flex: 1, fontSize: 12, fontWeight: '500', color: Colors.textMuted, lineHeight: 18 },
  startBtn: {
    padding: 16, borderRadius: Radius.lg, alignItems: 'center',
    ...Shadow.hero,
  },
  startBtnText: { color: 'white', fontSize: 16, fontWeight: '800' },
});
