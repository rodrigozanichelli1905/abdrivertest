// Driver Exam Prep – Exam Taking Screen (React Native)

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Modal, Alert,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useApp } from '../context/AppContext';
import { useExamSession } from '../context/ExamSessionContext';
import { t } from '../i18n';
import { Colors, Radius } from '../components/theme';
import type { RootStackParamList } from '../types';

type NavProp = NativeStackNavigationProp<RootStackParamList>;

export default function ExamTakingScreen() {
  const { saveAttempt, lang } = useApp();
  const session = useExamSession();
  const navigation = useNavigation<NavProp>();
  const route = useRoute<any>();
  const examId: number = route.params?.examId;
  const [showConfirm, setShowConfirm] = useState(false);

  const { exam, currentIndex, currentQuestion, totalQuestions, answeredCount, allAnswered, hasNext, hasPrevious } = session;

  if (!exam || !currentQuestion) return null;

  const progress = totalQuestions > 0 ? (currentIndex + 1) / totalQuestions : 0;
  const selectedAnswer = session.selectedAnswerFor(currentQuestion.id);

  function handleSubmit() {
    if (!allAnswered) {
      setShowConfirm(true);
    } else {
      doSubmit();
    }
  }

  function doSubmit() {
    const attempt = session.buildAttempt();
    saveAttempt(attempt);
    session.resetSession();
    navigation.replace('ExamResults', {
      examId,
      attemptData: JSON.stringify(attempt),
    });
  }

  return (
    <View style={styles.container}>
      {/* Header info */}
      <View style={styles.headerInfo}>
        <Text style={styles.headerTitle}>{t(lang, 'practiceTest')} {exam.id}</Text>
        <Text style={styles.headerSub}>
          {t(lang, 'question')} {currentIndex + 1} {t(lang, 'of')} {totalQuestions} · {answeredCount} {t(lang, 'answered')}
        </Text>
      </View>

      {/* Progress bar */}
      <View style={styles.progressBg}>
        <View style={[styles.progressBar, { width: `${progress * 100}%` as any }]} />
      </View>

      {/* Question dots */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.dotsScroll} contentContainerStyle={styles.dotsContent}>
        {exam.questions.map((q, i) => {
          const ans = session.selectedAnswerFor(q.id);
          const isCurrent = i === currentIndex;
          return (
            <TouchableOpacity
              key={i}
              onPress={() => session.goToQuestion(i)}
              style={[
                styles.dot,
                isCurrent && { backgroundColor: Colors.orange, transform: [{ scale: 1.15 }] },
                !isCurrent && ans !== undefined && { backgroundColor: Colors.teal },
              ]}
            >
              <Text style={[styles.dotText, (isCurrent || ans !== undefined) && { color: 'white' }]}>{i + 1}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Question */}
      <ScrollView style={styles.questionScroll} contentContainerStyle={styles.questionContent}>
        <View style={styles.questionCard}>
          <Text style={styles.questionLabel}>{t(lang, 'question')} {currentIndex + 1}</Text>
          <Text style={styles.questionText}>{currentQuestion.text}</Text>
        </View>

        {currentQuestion.options.map((option, i) => {
          const isSelected = selectedAnswer === i;
          return (
            <TouchableOpacity
              key={i}
              style={[styles.optionBtn, isSelected && styles.optionBtnSelected]}
              onPress={() => session.selectAnswer(i)}
              activeOpacity={0.7}
            >
              <View style={[styles.optionLetter, isSelected && { backgroundColor: Colors.orange }]}>
                <Text style={[styles.optionLetterText, isSelected && { color: 'white' }]}>
                  {String.fromCharCode(65 + i)}
                </Text>
              </View>
              <Text style={[styles.optionText, isSelected && { color: Colors.textDark, fontWeight: '700' }]}>
                {option}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Navigation bar */}
      <View style={styles.navBar}>
        <TouchableOpacity
          style={[styles.navBtn, !hasPrevious && { opacity: 0.4 }]}
          onPress={() => session.previousQuestion()}
          disabled={!hasPrevious}
          activeOpacity={0.7}
        >
          <Text style={styles.navBtnText}>← {t(lang, 'prev')}</Text>
        </TouchableOpacity>
        <Text style={styles.navCount}>{currentIndex + 1}/{totalQuestions}</Text>
        <TouchableOpacity
          style={[styles.navBtnPrimary]}
          onPress={() => hasNext ? session.nextQuestion() : handleSubmit()}
          activeOpacity={0.8}
        >
          <Text style={styles.navBtnPrimaryText}>
            {hasNext ? `${t(lang, 'next')} →` : t(lang, 'finish')}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Submit confirm modal */}
      <Modal visible={showConfirm} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>{t(lang, 'submitExam')}</Text>
            <Text style={styles.modalBody}>
              {t(lang, 'submitConfirmBody', {
                answered: answeredCount,
                total: totalQuestions,
                remaining: totalQuestions - answeredCount,
              })}
            </Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.modalBtnSecondary} onPress={() => setShowConfirm(false)}>
                <Text style={styles.modalBtnSecondaryText}>{t(lang, 'keepGoing')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalBtnPrimary} onPress={() => { setShowConfirm(false); doSubmit(); }}>
                <Text style={styles.modalBtnPrimaryText}>{t(lang, 'submit')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  headerInfo: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 4 },
  headerTitle: { fontSize: 14, fontWeight: '800', color: Colors.textDark },
  headerSub: { fontSize: 11, fontWeight: '600', color: Colors.textMuted, marginTop: 1 },
  progressBg: { height: 6, backgroundColor: Colors.border, marginHorizontal: 16, borderRadius: 3, marginBottom: 8 },
  progressBar: { height: 6, borderRadius: 3, backgroundColor: Colors.orange },
  dotsScroll: { maxHeight: 36, marginBottom: 8 },
  dotsContent: { paddingHorizontal: 16, gap: 4, alignItems: 'center' },
  dot: {
    width: 26, height: 26, borderRadius: 13,
    backgroundColor: Colors.border, alignItems: 'center', justifyContent: 'center',
  },
  dotText: { fontSize: 10, fontWeight: '700', color: Colors.textMuted },
  questionScroll: { flex: 1 },
  questionContent: { padding: 16, paddingBottom: 8 },
  questionCard: {
    backgroundColor: Colors.white, borderRadius: Radius.lg, padding: 14,
    borderWidth: 1, borderColor: Colors.border, marginBottom: 12,
  },
  questionLabel: { fontSize: 11, fontWeight: '700', color: Colors.orange, marginBottom: 6 },
  questionText: { fontSize: 15, fontWeight: '700', color: Colors.textDark, lineHeight: 22 },
  optionBtn: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 10,
    backgroundColor: Colors.white, borderRadius: Radius.lg, padding: 14,
    borderWidth: 1, borderColor: Colors.border, marginBottom: 10,
  },
  optionBtnSelected: { borderColor: Colors.orange, borderWidth: 2, backgroundColor: '#FF7A3C08' },
  optionLetter: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: Colors.border, alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  optionLetterText: { fontSize: 12, fontWeight: '800', color: Colors.textMuted },
  optionText: { flex: 1, fontSize: 13, fontWeight: '600', color: Colors.textDark, lineHeight: 20, paddingTop: 4 },
  navBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    backgroundColor: Colors.white, borderTopWidth: 1, borderTopColor: Colors.border,
  },
  navBtn: {
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: Radius.md,
    backgroundColor: Colors.border,
  },
  navBtnText: { fontSize: 13, fontWeight: '700', color: Colors.textDark },
  navCount: { fontSize: 12, fontWeight: '700', color: Colors.textMuted },
  navBtnPrimary: {
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: Radius.md,
    backgroundColor: Colors.orange,
  },
  navBtnPrimaryText: { fontSize: 13, fontWeight: '700', color: 'white' },
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center', justifyContent: 'center', padding: 24,
  },
  modalCard: {
    backgroundColor: Colors.white, borderRadius: Radius.xxl, padding: 24, width: '100%',
  },
  modalTitle: { fontSize: 18, fontWeight: '900', color: Colors.textDark, marginBottom: 8 },
  modalBody: { fontSize: 13, fontWeight: '500', color: Colors.textMuted, lineHeight: 20, marginBottom: 20 },
  modalBtns: { flexDirection: 'row', gap: 10 },
  modalBtnSecondary: {
    flex: 1, padding: 12, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, alignItems: 'center',
  },
  modalBtnSecondaryText: { fontSize: 13, fontWeight: '700', color: Colors.textMuted },
  modalBtnPrimary: {
    flex: 1, padding: 12, borderRadius: Radius.lg,
    backgroundColor: Colors.orange, alignItems: 'center',
  },
  modalBtnPrimaryText: { fontSize: 13, fontWeight: '700', color: 'white' },
});
