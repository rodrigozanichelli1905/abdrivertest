// Driver Exam Prep – Home Screen (React Native)
// Prairie Sunset Native: hero, categories, recent exams

import React, { useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { Colors, Radius, Shadow } from '../components/theme';
import type { RootStackParamList } from '../types';

const { width } = Dimensions.get('window');

type NavProp = NativeStackNavigationProp<RootStackParamList>;

const CATEGORIES = [
  { key: 'catRoadSigns' as const, color: Colors.deepOrange, filters: ['road signs', 'sinales', 'sinais'] },
  { key: 'catRightOfWay' as const, color: Colors.yellow, filters: ['right-of-way', 'intersections', 'derecho', 'preferencia'] },
  { key: 'catGdlRules' as const, color: Colors.teal, filters: ['gdl'] },
  { key: 'catHighways' as const, color: Colors.orange, filters: ['highway', 'autopista', 'rodovia'] },
];

function ProgressRing({ progress, size = 72 }: { progress: number; size?: number }) {
  const pct = Math.round(progress * 100);
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View style={{
        width: size, height: size, borderRadius: size / 2,
        borderWidth: 6, borderColor: 'rgba(255,255,255,0.25)',
        alignItems: 'center', justifyContent: 'center', position: 'absolute',
      }} />
      <Text style={{ color: 'white', fontSize: 18, fontWeight: '900' }}>{pct}%</Text>
      <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 8, fontWeight: '700', textAlign: 'center' }}>
        EXAM{'\n'}READY
      </Text>
    </View>
  );
}

export default function HomeScreen() {
  const { exams, loading, examsPassedCount, getBestAttempt, lang } = useApp();
  const navigation = useNavigation<NavProp>();

  const totalExams = exams.length;
  const progress = totalExams > 0 ? examsPassedCount / totalExams : 0;
  const readiness = progress >= 0.7
    ? t(lang, 'heroReadinessGreat')
    : progress >= 0.4
    ? t(lang, 'heroReadinessGood')
    : t(lang, 'heroReadinessPractice');

  const recentExams = exams.slice(0, 5);

  if (loading) {
    return (
      <View style={[styles.container, { alignItems: 'center', justifyContent: 'center' }]}>
        <View style={styles.loadingIcon}>
          <Text style={{ fontSize: 32 }}>🚗</Text>
        </View>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Hero */}
      <View style={styles.hero}>
        <View style={styles.heroDecCircle1} />
        <View style={styles.heroDecCircle2} />
        {/* Brand row */}
        <View style={styles.heroBrandRow}>
          <View style={styles.heroIconBox}>
            <Text style={{ fontSize: 18 }}>🚗</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroBrandName}>AB Driver Test</Text>
            <Text style={styles.heroBrandSub}>Alberta Class 7 Prep</Text>
          </View>
          <View style={styles.heroBadge}>
            <Text style={styles.heroBadgeText}>{t(lang, 'heroBadge')}</Text>
          </View>
        </View>
        {/* Stats row */}
        <View style={styles.heroStatsRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroPercent}>{Math.round(progress * 100)}%</Text>
            <Text style={styles.heroReadiness}>{readiness}</Text>
            <Text style={styles.heroSubtext}>{examsPassedCount}/{totalExams} {t(lang, 'heroExamsPassed')}</Text>
          </View>
          <ProgressRing progress={progress} />
        </View>
      </View>

      {/* Categories */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t(lang, 'studyByCategory')}</Text>
        <View style={styles.categoriesRow}>
          {CATEGORIES.map((cat) => (
            <TouchableOpacity
              key={cat.key}
              style={styles.categoryItem}
              onPress={() => navigation.navigate('MainTabs', { screen: 'Practice', params: { categoryFilters: cat.filters } } as any)}
              activeOpacity={0.7}
            >
              <View style={[styles.categoryIcon, { backgroundColor: cat.color, shadowColor: cat.color }]}>
                <Text style={{ fontSize: 20 }}>
                  {cat.key === 'catRoadSigns' ? '⚠️' : cat.key === 'catRightOfWay' ? '↔️' : cat.key === 'catGdlRules' ? '🪪' : '🏎️'}
                </Text>
              </View>
              <Text style={styles.categoryLabel}>{t(lang, cat.key)}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Recent Exams */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t(lang, 'startPracticing')}</Text>
          <TouchableOpacity onPress={() => navigation.navigate('MainTabs', { screen: 'Practice' } as any)}>
            <Text style={styles.seeAll}>{t(lang, 'seeAll')} →</Text>
          </TouchableOpacity>
        </View>
        {recentExams.map((exam, i) => {
          const best = getBestAttempt(exam.id);
          const isPassed = best && best.score >= 25;
          const grad = i % 2 === 0 ? Colors.orange : Colors.teal;
          return (
            <TouchableOpacity
              key={exam.id}
              style={styles.examCard}
              onPress={() => navigation.navigate('ExamIntro', { examId: exam.id })}
              activeOpacity={0.7}
            >
              <View style={[styles.examBadge, { backgroundColor: grad }]}>
                <Text style={styles.examBadgeText}>#{exam.id}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.examTitle}>{t(lang, 'practiceTest')} {exam.id}</Text>
                <Text style={styles.examSub}>{exam.questions.length} {t(lang, 'questions')} · {exam.category}</Text>
              </View>
              {best ? (
                <View style={{ alignItems: 'flex-end' }}>
                  <View style={[styles.scorePill, { backgroundColor: isPassed ? '#2E9E5B18' : '#E0483E18' }]}>
                    <Text style={[styles.scorePillText, { color: isPassed ? Colors.success : Colors.danger }]}>
                      {best.score}/{exam.questions.length}
                    </Text>
                  </View>
                  <Text style={[styles.examStatus, { color: isPassed ? Colors.success : Colors.danger }]}>
                    {isPassed ? t(lang, 'passed') : t(lang, 'failed')}
                  </Text>
                </View>
              ) : (
                <Text style={styles.notTried}>{t(lang, 'notTried')}</Text>
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { paddingBottom: 24 },
  loadingIcon: { width: 64, height: 64, borderRadius: 20, backgroundColor: Colors.orange, alignItems: 'center', justifyContent: 'center' },

  // Hero
  hero: {
    margin: 16,
    borderRadius: Radius.xxl,
    backgroundColor: Colors.orange,
    padding: 20,
    overflow: 'hidden',
    ...Shadow.hero,
  },
  heroDecCircle1: {
    position: 'absolute', top: -30, right: -30,
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  heroDecCircle2: {
    position: 'absolute', top: 10, right: 10,
    width: 50, height: 50, borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  heroBrandRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 },
  heroIconBox: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center',
  },
  heroBrandName: { color: 'white', fontSize: 15, fontWeight: '900' },
  heroBrandSub: { color: 'rgba(255,255,255,0.7)', fontSize: 10, fontWeight: '600' },
  heroBadge: {
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  heroBadgeText: { color: 'white', fontSize: 10, fontWeight: '700' },
  heroStatsRow: { flexDirection: 'row', alignItems: 'center' },
  heroPercent: { color: 'white', fontSize: 36, fontWeight: '900', lineHeight: 40 },
  heroReadiness: { color: 'rgba(255,255,255,0.9)', fontSize: 13, fontWeight: '700', marginTop: 2 },
  heroSubtext: { color: 'rgba(255,255,255,0.7)', fontSize: 11, marginTop: 2 },

  // Sections
  section: { paddingHorizontal: 16, marginTop: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '800', color: Colors.textDark, marginBottom: 12 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  seeAll: { fontSize: 12, fontWeight: '700', color: Colors.orange },

  // Categories
  categoriesRow: { flexDirection: 'row', justifyContent: 'space-between' },
  categoryItem: { alignItems: 'center', flex: 1 },
  categoryIcon: {
    width: 52, height: 52, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35, shadowRadius: 8, elevation: 4,
  },
  categoryLabel: {
    fontSize: 10, fontWeight: '700', color: Colors.textDark,
    textAlign: 'center', marginTop: 6, lineHeight: 13,
  },

  // Exam cards
  examCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: Colors.white, borderRadius: Radius.lg,
    padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: Colors.border,
    ...Shadow.card,
  },
  examBadge: {
    width: 46, height: 46, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center',
  },
  examBadgeText: { color: 'white', fontWeight: '900', fontSize: 13 },
  examTitle: { fontSize: 13, fontWeight: '800', color: Colors.textDark },
  examSub: { fontSize: 11, fontWeight: '600', color: Colors.textMuted, marginTop: 2 },
  scorePill: {
    paddingHorizontal: 8, paddingVertical: 2, borderRadius: 20,
  },
  scorePillText: { fontSize: 11, fontWeight: '800' },
  examStatus: { fontSize: 10, fontWeight: '600', marginTop: 2 },
  notTried: { fontSize: 10, fontWeight: '600', color: Colors.textMuted },
});
