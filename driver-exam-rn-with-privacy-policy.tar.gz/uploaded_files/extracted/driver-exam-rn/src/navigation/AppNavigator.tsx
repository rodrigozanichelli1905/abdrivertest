// Driver Exam Prep – App Navigator (React Native)
// Stack navigator wrapping bottom tab navigator

import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text, View } from 'react-native';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { Colors } from '../components/theme';

import HomeScreen from '../screens/HomeScreen';
import PracticeScreen from '../screens/PracticeScreen';
import SignsScreen from '../screens/SignsScreen';
import ProfileScreen from '../screens/ProfileScreen';
import ExamIntroScreen from '../screens/ExamIntroScreen';
import ExamTakingScreen from '../screens/ExamTakingScreen';
import ExamResultsScreen from '../screens/ExamResultsScreen';
import FlashcardStudyScreen from '../screens/FlashcardStudyScreen';

import type { RootStackParamList, TabParamList } from '../types';

const Tab = createBottomTabNavigator<TabParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

function TabIcon({ emoji, focused, color }: { emoji: string; focused: boolean; color: string }) {
  return (
    <View style={{
      width: 40, height: 40, borderRadius: 12,
      alignItems: 'center', justifyContent: 'center',
      backgroundColor: focused ? `${color}18` : 'transparent',
    }}>
      <Text style={{ fontSize: 20 }}>{emoji}</Text>
    </View>
  );
}

function MainTabs() {
  const { lang } = useApp();

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: Colors.white,
          borderTopColor: Colors.border,
          borderTopWidth: 1,
          height: 70,
          paddingBottom: 8,
          paddingTop: 4,
        },
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: '700',
        },
        tabBarActiveTintColor: Colors.orange,
        tabBarInactiveTintColor: Colors.textMuted,
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarLabel: t(lang, 'navHome'),
          tabBarIcon: ({ focused, color }) => <TabIcon emoji="🏠" focused={focused} color={color} />,
        }}
      />
      <Tab.Screen
        name="Signs"
        component={SignsScreen}
        options={{
          tabBarLabel: t(lang, 'navSigns'),
          tabBarIcon: ({ focused, color }) => <TabIcon emoji="🚦" focused={focused} color={color} />,
        }}
      />
      <Tab.Screen
        name="Practice"
        component={PracticeScreen}
        options={{
          tabBarLabel: t(lang, 'navPractice'),
          tabBarIcon: ({ focused, color }) => <TabIcon emoji="📋" focused={focused} color={color} />,
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarLabel: t(lang, 'navProfile'),
          tabBarIcon: ({ focused, color }) => <TabIcon emoji="👤" focused={focused} color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { lang } = useApp();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: Colors.background,
        },
        headerTintColor: Colors.textDark,
        headerTitleStyle: { fontWeight: '800', fontSize: 16 },
        headerShadowVisible: false,
        contentStyle: { backgroundColor: Colors.background },
      }}
    >
      <Stack.Screen
        name="MainTabs"
        component={MainTabs}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ExamIntro"
        component={ExamIntroScreen}
        options={{ title: t(lang, 'examDetails') }}
      />
      <Stack.Screen
        name="ExamTaking"
        component={ExamTakingScreen}
        options={{ title: t(lang, 'practiceTest'), headerBackVisible: true }}
      />
      <Stack.Screen
        name="ExamResults"
        component={ExamResultsScreen}
        options={{ title: t(lang, 'results'), headerBackVisible: false }}
      />
      <Stack.Screen
        name="FlashcardStudy"
        component={FlashcardStudyScreen}
        options={{ title: t(lang, 'flashcardStudy') }}
      />
    </Stack.Navigator>
  );
}
