// Driver Exam Prep – i18n for React Native
// Supports English (en), Spanish (es), Portuguese Brazil (pt-BR)

import type { LangCode } from '../types';

export interface Translations {
  appTitle: string;
  disclaimerTitle: string;
  disclaimerBody: string;
  disclaimerImportant: string;
  disclaimerImportantBody: string;
  disclaimerBody2: string;
  disclaimerBody3: string;
  disclaimerButton: string;
  navHome: string;
  navSigns: string;
  navPractice: string;
  navProfile: string;
  heroBadge: string;
  heroReadinessGreat: string;
  heroReadinessGood: string;
  heroReadinessPractice: string;
  heroExamsPassed: string;
  studyByCategory: string;
  catRoadSigns: string;
  catRightOfWay: string;
  catGdlRules: string;
  catHighways: string;
  startPracticing: string;
  seeAll: string;
  notTried: string;
  passed: string;
  failed: string;
  allPracticeExams: string;
  filteredByCategory: string;
  clearFilter: string;
  noExamsFound: string;
  questions: string;
  examDetails: string;
  noTimeLimit: string;
  unlimited: string;
  passScore: string;
  bestScore: string;
  attempts: string;
  howItWorks: string;
  howItWorks1: string;
  howItWorks2: string;
  howItWorks3: string;
  howItWorks4: string;
  howItWorks5: string;
  startExam: string;
  retakeExam: string;
  question: string;
  of: string;
  answered: string;
  submit: string;
  prev: string;
  next: string;
  finish: string;
  submitExam: string;
  submitConfirmBody: string;
  keepGoing: string;
  results: string;
  outOf: string;
  correct: string;
  wrong: string;
  score: string;
  retake: string;
  backToExams: string;
  studyMissedCards: string;
  reviewAllAnswers: string;
  tapToReveal: string;
  yourAnswer: string;
  explanation: string;
  flashcardStudy: string;
  known: string;
  tapToRevealAnswer: string;
  answer: string;
  allOptions: string;
  stillLearning: string;
  gotIt: string;
  sessionComplete: string;
  sessionDone: string;
  reviewedCards: string;
  gotItCount: string;
  needReview: string;
  reviewMissed: string;
  restartAll: string;
  backToResults: string;
  myProgress: string;
  examsPassed: string;
  allExamsUnlocked: string;
  attempted: string;
  remaining: string;
  recentAttempts: string;
  noAttempts: string;
  resetProgress: string;
  resetConfirm: string;
  cancel: string;
  reset: string;
  roadSignsGuide: string;
  roadSignsSubtitle: string;
  signDisclaimer: string;
  signDisclaimerBody: string;
  language: string;
  practiceTest: string;
  categoryStats: string;
  categoryStatsSubtitle: string;
  noCategoryStats: string;
  accuracy: string;
  weakest: string;
  strongest: string;
  questionsAnswered: string;
  examsOf: string;
}

const en: Translations = {
  appTitle: 'Driver Exam Prep',
  disclaimerTitle: 'Before You Begin',
  disclaimerBody: 'This app is designed to help you prepare for the Alberta Class 7 Learner\'s Licence knowledge test.',
  disclaimerImportant: 'Important:',
  disclaimerImportantBody: 'This app is for practice purposes only and is not affiliated with the Government of Alberta or any official licensing authority.',
  disclaimerBody2: 'Always refer to the official Alberta Driver\'s Guide for accurate information.',
  disclaimerBody3: 'Passing practice exams does not guarantee passing the official test.',
  disclaimerButton: 'I Understand',
  navHome: 'Home',
  navSigns: 'Signs',
  navPractice: 'Practice',
  navProfile: 'Profile',
  heroBadge: 'Pass First Try',
  heroReadinessGreat: 'Great Progress!',
  heroReadinessGood: 'Good Progress!',
  heroReadinessPractice: 'Keep Practicing!',
  heroExamsPassed: 'exams passed',
  studyByCategory: 'Study by Category',
  catRoadSigns: 'Road Signs',
  catRightOfWay: 'Right of Way',
  catGdlRules: 'GDL Rules',
  catHighways: 'Highways',
  startPracticing: 'Start Practicing',
  seeAll: 'See all',
  notTried: 'Not tried',
  passed: 'Passed',
  failed: 'Failed',
  allPracticeExams: 'All Practice Exams',
  filteredByCategory: 'Filtered by category',
  clearFilter: 'Clear filter',
  noExamsFound: 'No exams found for this category.',
  questions: 'Questions',
  examDetails: 'Exam Details',
  noTimeLimit: 'No Time Limit',
  unlimited: 'Unlimited',
  passScore: 'Pass Score',
  bestScore: 'Best Score:',
  attempts: 'attempt',
  howItWorks: 'How it works',
  howItWorks1: 'Answer all 30 questions at your own pace',
  howItWorks2: 'Navigate freely between questions',
  howItWorks3: 'Submit when ready to see your results',
  howItWorks4: 'Review explanations for every answer',
  howItWorks5: 'Score 25+ out of 30 to pass',
  startExam: 'Start Exam',
  retakeExam: 'Retake Exam',
  question: 'Question',
  of: 'of',
  answered: 'answered',
  submit: 'Submit',
  prev: 'Prev',
  next: 'Next',
  finish: 'Finish',
  submitExam: 'Submit Exam?',
  submitConfirmBody: 'You have answered {answered} of {total} questions. {remaining} unanswered will be marked incorrect.',
  keepGoing: 'Keep Going',
  results: 'Results',
  outOf: 'out of',
  correct: 'Correct',
  wrong: 'Wrong',
  score: 'Score',
  retake: 'Retake',
  backToExams: 'Back to Exams',
  studyMissedCards: 'Study {count} Missed Card(s)',
  reviewAllAnswers: 'Review All Answers',
  tapToReveal: 'Tap to reveal answer',
  yourAnswer: 'Your answer',
  explanation: 'Explanation:',
  flashcardStudy: 'Flashcard Study',
  known: 'known',
  tapToRevealAnswer: 'Tap to reveal answer',
  answer: 'Answer',
  allOptions: 'All options:',
  stillLearning: 'Still Learning',
  gotIt: 'Got It!',
  sessionComplete: 'Session Complete',
  sessionDone: 'Session Done!',
  reviewedCards: 'You reviewed {count} flashcard(s)',
  gotItCount: 'Got it',
  needReview: 'Need review',
  reviewMissed: 'Review {count} Missed Card(s)',
  restartAll: 'Restart All Cards',
  backToResults: 'Back to Results',
  myProgress: 'My Progress',
  examsPassed: 'Exams Passed',
  allExamsUnlocked: 'All {count} practice exams unlocked',
  attempted: 'Attempted',
  remaining: 'Remaining',
  recentAttempts: 'Recent Attempts',
  noAttempts: 'No attempts yet. Start a practice exam!',
  resetProgress: 'Reset All Progress',
  resetConfirm: 'Are you sure? This will delete all your exam history.',
  cancel: 'Cancel',
  reset: 'Reset',
  roadSignsGuide: 'Road Signs Guide',
  roadSignsSubtitle: 'Alberta road sign shapes and their meanings',
  signDisclaimer: 'Disclaimer:',
  signDisclaimerBody: 'This guide is for study purposes only. Always refer to the official Alberta Driver\'s Guide.',
  language: 'Language',
  practiceTest: 'Practice Test',
  categoryStats: 'Performance by Category',
  categoryStatsSubtitle: 'Based on your best attempt per exam',
  noCategoryStats: 'Complete at least one exam to see your category stats.',
  accuracy: 'Accuracy',
  weakest: 'Needs Work',
  strongest: 'Strong',
  questionsAnswered: 'questions answered',
  examsOf: 'of',
};

const es: Translations = {
  appTitle: 'Preparacion Examen',
  disclaimerTitle: 'Antes de Comenzar',
  disclaimerBody: 'Esta aplicacion esta disenada para ayudarte a prepararte para el examen de la Licencia de Aprendiz Clase 7 de Alberta.',
  disclaimerImportant: 'Importante:',
  disclaimerImportantBody: 'Esta aplicacion es solo para fines de practica y no esta afiliada con el Gobierno de Alberta ni ninguna autoridad oficial.',
  disclaimerBody2: 'Siempre consulta la Guia Oficial del Conductor de Alberta para informacion precisa.',
  disclaimerBody3: 'Aprobar los examenes de practica no garantiza aprobar el examen oficial.',
  disclaimerButton: 'Entendido',
  navHome: 'Inicio',
  navSigns: 'Senales',
  navPractice: 'Practica',
  navProfile: 'Perfil',
  heroBadge: 'Aprueba al Primer Intento',
  heroReadinessGreat: 'Excelente Progreso!',
  heroReadinessGood: 'Buen Progreso!',
  heroReadinessPractice: 'Sigue Practicando!',
  heroExamsPassed: 'examenes aprobados',
  studyByCategory: 'Estudiar por Categoria',
  catRoadSigns: 'Senales Viales',
  catRightOfWay: 'Derecho de Paso',
  catGdlRules: 'Reglas GDL',
  catHighways: 'Autopistas',
  startPracticing: 'Comenzar Practica',
  seeAll: 'Ver todo',
  notTried: 'Sin intentar',
  passed: 'Aprobado',
  failed: 'Reprobado',
  allPracticeExams: 'Todos los Examenes',
  filteredByCategory: 'Filtrado por categoria',
  clearFilter: 'Quitar filtro',
  noExamsFound: 'No se encontraron examenes para esta categoria.',
  questions: 'Preguntas',
  examDetails: 'Detalles del Examen',
  noTimeLimit: 'Sin Limite de Tiempo',
  unlimited: 'Ilimitado',
  passScore: 'Puntaje para Aprobar',
  bestScore: 'Mejor Puntaje:',
  attempts: 'intento',
  howItWorks: 'Como funciona',
  howItWorks1: 'Responde las 30 preguntas a tu propio ritmo',
  howItWorks2: 'Navega libremente entre preguntas',
  howItWorks3: 'Envia cuando estes listo para ver tus resultados',
  howItWorks4: 'Revisa las explicaciones de cada respuesta',
  howItWorks5: 'Necesitas 25+ de 30 para aprobar',
  startExam: 'Iniciar Examen',
  retakeExam: 'Repetir Examen',
  question: 'Pregunta',
  of: 'de',
  answered: 'respondidas',
  submit: 'Enviar',
  prev: 'Anterior',
  next: 'Siguiente',
  finish: 'Finalizar',
  submitExam: 'Enviar Examen?',
  submitConfirmBody: 'Has respondido {answered} de {total} preguntas. {remaining} sin responder se marcaran incorrectas.',
  keepGoing: 'Continuar',
  results: 'Resultados',
  outOf: 'de',
  correct: 'Correctas',
  wrong: 'Incorrectas',
  score: 'Puntaje',
  retake: 'Repetir',
  backToExams: 'Volver a Examenes',
  studyMissedCards: 'Estudiar {count} tarjeta(s) fallida(s)',
  reviewAllAnswers: 'Revisar Todas las Respuestas',
  tapToReveal: 'Toca para revelar la respuesta',
  yourAnswer: 'Tu respuesta',
  explanation: 'Explicacion:',
  flashcardStudy: 'Estudio con Flashcards',
  known: 'dominadas',
  tapToRevealAnswer: 'Toca para revelar la respuesta',
  answer: 'Respuesta',
  allOptions: 'Todas las opciones:',
  stillLearning: 'Aun Aprendiendo',
  gotIt: 'Ya lo Se!',
  sessionComplete: 'Sesion Completada',
  sessionDone: 'Sesion Lista!',
  reviewedCards: 'Revisaste {count} flashcard(s)',
  gotItCount: 'Dominadas',
  needReview: 'Necesitan repaso',
  reviewMissed: 'Repasar {count} tarjeta(s)',
  restartAll: 'Reiniciar Todas',
  backToResults: 'Volver a Resultados',
  myProgress: 'Mi Progreso',
  examsPassed: 'Examenes Aprobados',
  allExamsUnlocked: 'Los {count} examenes desbloqueados',
  attempted: 'Intentados',
  remaining: 'Pendientes',
  recentAttempts: 'Intentos Recientes',
  noAttempts: 'Sin intentos aun. Comienza un examen!',
  resetProgress: 'Reiniciar Todo el Progreso',
  resetConfirm: 'Estas seguro? Esto eliminara todo tu historial.',
  cancel: 'Cancelar',
  reset: 'Reiniciar',
  roadSignsGuide: 'Guia de Senales Viales',
  roadSignsSubtitle: 'Formas de senales viales de Alberta y sus significados',
  signDisclaimer: 'Aviso:',
  signDisclaimerBody: 'Esta guia es para fines de estudio. Siempre consulta la Guia Oficial del Conductor de Alberta.',
  language: 'Idioma',
  practiceTest: 'Examen de Practica',
  categoryStats: 'Rendimiento por Categoria',
  categoryStatsSubtitle: 'Basado en tu mejor intento por examen',
  noCategoryStats: 'Completa al menos un examen para ver tus estadisticas.',
  accuracy: 'Precision',
  weakest: 'Necesita Mejorar',
  strongest: 'Fuerte',
  questionsAnswered: 'preguntas respondidas',
  examsOf: 'de',
};

const ptBR: Translations = {
  appTitle: 'Prep Exame CNH',
  disclaimerTitle: 'Antes de Comecar',
  disclaimerBody: 'Este aplicativo foi desenvolvido para ajudar voce a se preparar para o exame de conhecimento da Carteira Classe 7 de Alberta.',
  disclaimerImportant: 'Importante:',
  disclaimerImportantBody: 'Este aplicativo e apenas para fins de pratica e nao tem afiliacao com o Governo de Alberta ou qualquer autoridade oficial.',
  disclaimerBody2: 'Sempre consulte o Guia Oficial do Motorista de Alberta para informacoes precisas.',
  disclaimerBody3: 'Passar nos exames de pratica nao garante a aprovacao no exame oficial.',
  disclaimerButton: 'Entendi',
  navHome: 'Inicio',
  navSigns: 'Sinais',
  navPractice: 'Pratica',
  navProfile: 'Perfil',
  heroBadge: 'Passe na Primeira Tentativa',
  heroReadinessGreat: 'Otimo Progresso!',
  heroReadinessGood: 'Bom Progresso!',
  heroReadinessPractice: 'Continue Praticando!',
  heroExamsPassed: 'exames aprovados',
  studyByCategory: 'Estudar por Categoria',
  catRoadSigns: 'Sinais de Transito',
  catRightOfWay: 'Preferencia de Passagem',
  catGdlRules: 'Regras GDL',
  catHighways: 'Rodovias',
  startPracticing: 'Comecar Pratica',
  seeAll: 'Ver todos',
  notTried: 'Nao tentado',
  passed: 'Aprovado',
  failed: 'Reprovado',
  allPracticeExams: 'Todos os Exames',
  filteredByCategory: 'Filtrado por categoria',
  clearFilter: 'Limpar filtro',
  noExamsFound: 'Nenhum exame encontrado para esta categoria.',
  questions: 'Questoes',
  examDetails: 'Detalhes do Exame',
  noTimeLimit: 'Sem Limite de Tempo',
  unlimited: 'Ilimitado',
  passScore: 'Pontuacao para Aprovacao',
  bestScore: 'Melhor Pontuacao:',
  attempts: 'tentativa',
  howItWorks: 'Como funciona',
  howItWorks1: 'Responda todas as 30 questoes no seu proprio ritmo',
  howItWorks2: 'Navegue livremente entre as questoes',
  howItWorks3: 'Envie quando estiver pronto para ver seus resultados',
  howItWorks4: 'Revise as explicacoes de cada resposta',
  howItWorks5: 'Precisa de 25+ de 30 para ser aprovado',
  startExam: 'Iniciar Exame',
  retakeExam: 'Refazer Exame',
  question: 'Questao',
  of: 'de',
  answered: 'respondidas',
  submit: 'Enviar',
  prev: 'Anterior',
  next: 'Proximo',
  finish: 'Finalizar',
  submitExam: 'Enviar Exame?',
  submitConfirmBody: 'Voce respondeu {answered} de {total} questoes. {remaining} sem resposta serao marcadas incorretas.',
  keepGoing: 'Continuar',
  results: 'Resultados',
  outOf: 'de',
  correct: 'Corretas',
  wrong: 'Incorretas',
  score: 'Pontuacao',
  retake: 'Refazer',
  backToExams: 'Voltar aos Exames',
  studyMissedCards: 'Estudar {count} cartao(oes) errado(s)',
  reviewAllAnswers: 'Revisar Todas as Respostas',
  tapToReveal: 'Toque para revelar a resposta',
  yourAnswer: 'Sua resposta',
  explanation: 'Explicacao:',
  flashcardStudy: 'Estudo com Flashcards',
  known: 'dominados',
  tapToRevealAnswer: 'Toque para revelar a resposta',
  answer: 'Resposta',
  allOptions: 'Todas as opcoes:',
  stillLearning: 'Ainda Aprendendo',
  gotIt: 'Entendi!',
  sessionComplete: 'Sessao Concluida',
  sessionDone: 'Sessao Pronta!',
  reviewedCards: 'Voce revisou {count} flashcard(s)',
  gotItCount: 'Dominados',
  needReview: 'Precisam de revisao',
  reviewMissed: 'Revisar {count} cartao(oes)',
  restartAll: 'Reiniciar Todos',
  backToResults: 'Voltar aos Resultados',
  myProgress: 'Meu Progresso',
  examsPassed: 'Exames Aprovados',
  allExamsUnlocked: 'Todos os {count} exames desbloqueados',
  attempted: 'Tentados',
  remaining: 'Pendentes',
  recentAttempts: 'Tentativas Recentes',
  noAttempts: 'Sem tentativas ainda. Comece um exame!',
  resetProgress: 'Redefinir Todo o Progresso',
  resetConfirm: 'Tem certeza? Isso apagara todo o seu historico.',
  cancel: 'Cancelar',
  reset: 'Redefinir',
  roadSignsGuide: 'Guia de Sinais de Transito',
  roadSignsSubtitle: 'Formatos de sinais de transito de Alberta e seus significados',
  signDisclaimer: 'Aviso:',
  signDisclaimerBody: 'Este guia e para fins de estudo. Sempre consulte o Guia Oficial do Motorista de Alberta.',
  language: 'Idioma',
  practiceTest: 'Exame de Pratica',
  categoryStats: 'Desempenho por Categoria',
  categoryStatsSubtitle: 'Baseado na sua melhor tentativa por exame',
  noCategoryStats: 'Complete pelo menos um exame para ver suas estatisticas.',
  accuracy: 'Precisao',
  weakest: 'Precisa Melhorar',
  strongest: 'Forte',
  questionsAnswered: 'questoes respondidas',
  examsOf: 'de',
};

export const translations: Record<LangCode, Translations> = {
  en,
  es,
  'pt-BR': ptBR,
};

export function t(
  lang: LangCode,
  key: keyof Translations,
  vars?: Record<string, string | number>
): string {
  let str = translations[lang][key] as string;
  if (vars) {
    for (const [k, v] of Object.entries(vars)) {
      str = str.replace(`{${k}}`, String(v));
    }
  }
  return str;
}

export const LANG_OPTIONS: { code: LangCode; label: string; flag: string }[] = [
  { code: 'en', label: 'English', flag: '🇨🇦' },
  { code: 'es', label: 'Espanol', flag: '🇲🇽' },
  { code: 'pt-BR', label: 'Portugues (BR)', flag: '🇧🇷' },
];
