// Driver Exam Prep – TypeScript Types

export interface Question {
  id: string;
  text: string;
  options: string[];
  correct: number;
  explanation: string;
}

export interface Exam {
  id: number;
  title: string;
  category: string;
  questions: Question[];
}

export interface ExamData {
  exams: Exam[];
}

export interface ExamAttempt {
  examId: number;
  score: number;
  totalQuestions: number;
  completedAt: string; // ISO string
  answers: Record<string, number>; // questionId -> selected option index
  passed: boolean;
}

export type LangCode = 'en' | 'es' | 'pt-BR';

export type RootStackParamList = {
  MainTabs: undefined;
  ExamIntro: { examId: number };
  ExamTaking: { examId: number };
  ExamResults: { examId: number; attemptData: string }; // JSON stringified attempt
  FlashcardStudy: { questionsData: string; title: string }; // JSON stringified questions
};

export type TabParamList = {
  Home: undefined;
  Signs: undefined;
  Practice: { categoryFilters?: string[] };
  Profile: undefined;
};
