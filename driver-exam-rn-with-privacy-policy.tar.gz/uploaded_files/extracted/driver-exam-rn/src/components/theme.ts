// Driver Exam Prep – Design Tokens (Prairie Sunset Native)
// Orange #FF7A3C, Teal #1E8A8A, Yellow #FFC94A, Cream #FAF6F1

export const Colors = {
  orange: '#FF7A3C',
  deepOrange: '#E85D2A',
  teal: '#1E8A8A',
  deepTeal: '#14615F',
  yellow: '#FFC94A',
  success: '#2E9E5B',
  danger: '#E0483E',
  background: '#FAF6F1',
  white: '#FFFFFF',
  textDark: '#262019',
  textMuted: '#6E655D',
  border: 'rgba(240,233,226,1)',
  cardBg: '#FFFFFF',
};

export const Gradients = {
  orange: ['#FF7A3C', '#E85D2A'] as const,
  teal: ['#1E8A8A', '#14615F'] as const,
  success: ['#2E9E5B', '#1a7a42'] as const,
  danger: ['#E0483E', '#b83530'] as const,
};

export const Fonts = {
  regular: 'System',
  bold: 'System',
};

export const Radius = {
  sm: 10,
  md: 14,
  lg: 20,
  xl: 24,
  xxl: 28,
};

export const Shadow = {
  card: {
    shadowColor: '#262019',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 3,
  },
  hero: {
    shadowColor: '#FF7A3C',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 6,
  },
};
