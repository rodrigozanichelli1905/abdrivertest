// Driver Exam Prep – Disclaimer Modal (React Native)

import React from 'react';
import {
  Modal, View, Text, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { Colors, Radius, Shadow } from './theme';

interface DisclaimerModalProps {
  visible: boolean;
  onAccept: () => void;
}

export default function DisclaimerModal({ visible, onAccept }: DisclaimerModalProps) {
  const { lang } = useApp();

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.card}>
          <Text style={styles.title}>{t(lang, 'disclaimerTitle')}</Text>
          <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
            <Text style={styles.body}>{t(lang, 'disclaimerBody')}</Text>
            <Text style={styles.body}>
              <Text style={styles.bold}>{t(lang, 'disclaimerImportant')} </Text>
              {t(lang, 'disclaimerImportantBody')}
            </Text>
            <Text style={styles.body}>{t(lang, 'disclaimerBody2')}</Text>
            <Text style={styles.body}>{t(lang, 'disclaimerBody3')}</Text>
          </ScrollView>
          <TouchableOpacity style={styles.btn} onPress={onAccept} activeOpacity={0.8}>
            <Text style={styles.btnText}>{t(lang, 'disclaimerButton')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.5)',
    alignItems: 'center', justifyContent: 'center', padding: 24,
  },
  card: {
    backgroundColor: Colors.white, borderRadius: Radius.xxl,
    padding: 24, width: '100%', maxHeight: '80%',
    ...Shadow.hero,
  },
  title: { fontSize: 20, fontWeight: '900', color: Colors.textDark, marginBottom: 14 },
  scroll: { maxHeight: 260, marginBottom: 16 },
  body: {
    fontSize: 13, fontWeight: '500', color: Colors.textMuted,
    lineHeight: 20, marginBottom: 10,
    backgroundColor: Colors.background, padding: 10, borderRadius: Radius.sm,
  },
  bold: { fontWeight: '700', color: Colors.textDark },
  btn: {
    backgroundColor: Colors.orange, padding: 15, borderRadius: Radius.lg,
    alignItems: 'center', ...Shadow.hero,
  },
  btnText: { color: 'white', fontSize: 15, fontWeight: '800' },
});
