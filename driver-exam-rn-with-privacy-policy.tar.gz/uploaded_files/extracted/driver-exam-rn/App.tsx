// Driver Exam Prep – Root App Component (React Native + Expo)
// Bundle ID: com.driverexamprep.driverExamPrep
// Owner: rzanichelli | Apple Team: CLU43VVWZA

import React, { useState, useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { AppProvider, useApp } from './src/context/AppContext';
import { ExamSessionProvider } from './src/context/ExamSessionContext';
import AppNavigator from './src/navigation/AppNavigator';
import DisclaimerModal from './src/components/DisclaimerModal';

function AppContent() {
  const { disclaimerAcknowledged, acknowledgeDisclaimer, loading } = useApp();
  const [showDisclaimer, setShowDisclaimer] = useState(false);

  useEffect(() => {
    if (!loading && !disclaimerAcknowledged) {
      setShowDisclaimer(true);
    }
  }, [loading, disclaimerAcknowledged]);

  return (
    <>
      <StatusBar style="dark" />
      <AppNavigator />
      <DisclaimerModal
        visible={showDisclaimer}
        onAccept={() => {
          acknowledgeDisclaimer();
          setShowDisclaimer(false);
        }}
      />
    </>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppProvider>
          <ExamSessionProvider>
            <NavigationContainer>
              <AppContent />
            </NavigationContainer>
          </ExamSessionProvider>
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
